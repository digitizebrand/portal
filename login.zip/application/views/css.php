<link rel="publisher" href="https://plus.google.com/u/0/113811040143309481072"/>
<link href="https://digitaltrainee.com/css/bootstrap.css" rel="stylesheet">
<link href="https://digitaltrainee.com/css/style.css" rel="stylesheet">
<link href="https://digitaltrainee.com/fonts/stylesheet.css" rel="stylesheet">
<link href="https://digitaltrainee.com/css/font-awesome.css" rel="stylesheet">
<link href="https://digitaltrainee.com/css/menu.css" rel="stylesheet">
<link href="https://digitaltrainee.com/css/anim-load.css" rel="stylesheet">
<link href="https://digitaltrainee.com/css/owl.carousel.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel='stylesheet' type="text/css" href='https://digitaltrainee.com/css/validationEngine.jquery.css'/>
<link href="https://www.cssscript.com/wp-includes/css/sticky.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">