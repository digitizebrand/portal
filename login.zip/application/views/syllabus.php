<?php $this->load->view('header1');?>
<link href="<?php echo ASSETS;?>css/viewer-datauri.css" media="screen" rel="stylesheet" type="text/css">
  <link href="<?php echo ASSETS;?>css/print.css" media="print" rel="stylesheet" type="text/css">
  <script src="<?php echo ASSETS;?>js/viewer.js" type="text/javascript"></script>
  <script src="<?php echo ASSETS;?>js/templates.js" type="text/javascript"></script>
<div class="container">
	<h2 class="text-center">Latest Digital Marketing Syllabus</h2>
</div>
<div id="Iframe-Master-CC-and-Rs document-viewer" class="set-margin set-padding set-border set-box-shadow center-block-horiz" style="">
<div style="margin-top:1em" class="hidden-xs">&nbsp;</div>    
  <div class="embed-responsive embed-responsive-4by3" >
    <iframe id="ifr" class="col-lg-12 col-xs-12" src="
<?php echo base_url().$result->result[0]->name?>"> 
      <p style="font-size: 110%;"><em><strong>ERROR: </strong>  
An &#105;frame should be displayed here but your browser version does not support &#105;frames. </em>Please update your browser to its most recent version and try again.</p>
    </iframe>
    
  </div>
</div>
<?php $this->load->view('footer1');?>
<script type="text/javascript">
  window.currentDocument = DV.load(
    '<?php echo ASSETS;?>js/trump.js', {
      container: '#document-viewer',
    }
  );
</script>