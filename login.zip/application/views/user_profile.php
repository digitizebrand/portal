<?php $this->load->view('header1');?>
<style>
	$green: #96be11;
	@mixin inline {
		display: inline-block;
		*display: inline;
		zoom: 1;
		vertical-align: top;
	}

	body {
	  font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
	  background: #fff;
	  color: #757575;
	}
	.wrapper {
	  margin: 50px;
	}
	ol.breadcrumbs {
		margin: 25px 0px 0px;
		padding: 0px;
		font-size: 0px;
		line-height: 0px;
		@include inline;
		height: 40px;

		li {
			position: relative;
			margin: 0px 0px;
			padding: 0px;
			list-style: none;
			list-style-image: none;
			@include inline;
			border-left: 1px solid #ccc;
			transition: 0.3s ease;

			&:hover {
				&:before {
					border-left: 10px solid $green;
				}

				a {
					color: #000;
					background: $green;
				}

			}
			
			&:before {
				content:"";
				position: absolute;
				right: -9px;
				top: -1px;
				z-index: 20;
				border-left: 10px solid #fff;
				border-top: 22px solid transparent;
				border-bottom: 22px solid transparent;
				transition: 0.3s ease;
			}

			&:after {
				content:"";
				position: absolute;
				right: -10px;
				top: -1px;
				z-index: 10;
				border-left: 10px solid #ccc;
				border-top: 22px solid transparent;
				border-bottom: 22px solid transparent;
			}


			&.active {

				a {
					color: #000;
					background: $green;
				}
			}

			&.first {
				border-left: none;

				a {
					font-size: 18px;
					padding-left: 20px;
					border-radius: 5px 0px 0px 5px;
				}
			}

			&.last {

				&:before {
					display: none;
				}
				&:after {
					display: none;
				}

				a {
					padding-right: 20px;
					border-radius: 0px 40px 40px 0px;
				}
			}

			a {
				display: block;
				font-size: 12px;
				line-height: 40px;
				color: #757575;
				padding: 0px 15px 0px 25px;
				text-decoration: none;
				background: #fff;
				border: 1px solid #ddd;
				white-space:nowrap;
				overflow: hidden;
				transition: 0.3s ease;
			}
		}
	}
	</style>
            <!-- Page Content Breadcrumd -->
				<div class="col-md-12"> 
					<ol class="breadcrumbs breadcrumb-arrow">
					<?php
					$breadcrumb_details = json_decode($breadcrumb);
								$breadcrumb_count = count($breadcrumb_details);
								foreach ($breadcrumb_details as $breadcrumb) {
								//print_r($breadcrumb);
									?>
						<li class="<?php echo $breadcrumb->class; ?>"><a href="<?php echo $breadcrumb->link; ?>" <?php if(!empty($breadcrumb->class)){?>style='color:red;'<?php } ?>> <?php echo $breadcrumb->title; ?></a></li>
					   <?php }  ?>
					</ol>
				</div>
			<!-- Page Content Start -->
            <!-- ================== -->
            <div class="wraper container-fluid">
                <div class="page-title"> 
                    <h3 class="title">Welcome <?php echo ucfirst($this->session->userdata('user_name'));
    ?>!</h3> 
                </div>
                <div class="col-md-12 col-lg-12 col-sm-12">
                    <a href="<?php echo base_url('user/syllabus');?>">    <div class="col-lg-4 col-sm-6">
                        <div class="widget-panel widget-style-2 bg-pink">
						<center>						
                            <i class="fa fa-file-pdf-o" style="text-align:center! important;"></i> 
							<h2 class="m-0">Latest <br>Syllabus</h2>
							<div><?php echo date('jS F, Y',strtotime($result->result[0]->added_on));?></div>
                        </center>    
                        </div>
                    </div></a>
                    <a href="<?php echo base_url('user/videos');?>">
					<div class="col-lg-4 col-sm-6">
                        <div class="widget-panel widget-style-2 bg-purple">
						<center>	
                            <i class="glyphicon glyphicon-play-circle"></i> 
								<h2 class="m-0">Watch <br>Videos</h2>
						</center>	
                        </div>
                    </div>
					</a>
					<a href="<?php echo base_url('user/study-material');?>">
					<div class="col-lg-4 col-sm-6">
                        <div class="widget-panel widget-style-2 bg-info">	<center>
                            <i class="glyphicon glyphicon-list-alt"></i> 
                        	<h2 class="m-0" style="/*padding-top:2.5em*/">Study <br>Material</h2>
						<div><?php echo date('jS F, Y',strtotime($study_result->result[0]->added_on));?></div>
						</center>
                        </div>
                    </div>
					</a>
					<?php $active_link= 'javascript:void(0)';$alert="Oops! Your account is not fully activated. Please contact your trainer. Thank you";
						if($this->session->userdata('payment')==1){
							$active_link= base_url('user/domain-registration');
							$alert="";
						}
					?> 
					<a href="<?php echo $active_link;?>" <?php if($alert!=''){ ?>onclick="alert('<?php echo $alert?>')" <?php }
					?>>
					<div class="col-lg-4 col-sm-6">
                        <div class="widget-panel widget-style-2 bg-success">
						<center>
						     <i class="glyphicon glyphicon-globe"></i>
							<h2 class="m-0" >Domain Registration</h2>
						</center>
                        </div>
                    </div>
					</a>
					<?php $active_link= 'javascript:void(0)';$alert="Oops! Your account is not fully activated. Please contact your trainer. Thank you";
						if($this->session->userdata('payment')==1){
							$active_link= base_url('user/placements');
							$alert="";
							}
					?> 
					<a href="<?php echo $active_link;?>" <?php if($alert!=''){ ?>onclick="alert('<?php echo $alert?>')" <?php }
					?>>
					<div class="col-lg-4 col-sm-6">
                        <div class="widget-panel widget-style-2 bg-info">
						<center>						
                            <i class="glyphicon glyphicon-briefcase" style="text-align:center! important;"></i> 
							<h2 class="m-0">Placement <br>Alerts</h2>
					    </center>    
                        </div>
                    </div>
					</a>
                    <a href="<?php echo base_url('user/assignments');?>">
                    <div class="col-lg-4 col-sm-6">
                        <div class="widget-panel widget-style-2 bg-purple">
						<center>	
                            <i class="glyphicon glyphicon-tasks"></i> 
					        <h2 class="m-0">Assignments</h2>
						</center>	
                        </div>
                    </div>
					</a>
					<a href="<?php echo base_url('user/freelancing');?>">
					<div class="col-lg-4 col-sm-6">
                        <div class="widget-panel widget-style-2 bg-fb">
						<center>
						     <i class="fa fa-tags"></i>
								<h2 class="m-0">Freelancing Proposal <br>& Quotation</h2>
						</center>
                        </div>
                    </div>
					</a>
					<a href="<?php echo base_url('user/resume');?>">
					<div class="col-lg-4 col-sm-6">
                        <div class="widget-panel widget-style-2 bg-primary">
						<center>
							<i class="glyphicon glyphicon-file"></i>
								<h2 class="m-0" >Resume <br>Formats</h2>
							
						</center>
                        </div>
                    </div></a>
					<a href="<?php echo base_url('user/interview-questions-and-answers');?>">
					<div class="col-lg-4 col-sm-6">
                        <div class="widget-panel widget-style-2 bg-success">
						<center>
							<i class="fa fa-question-circle"></i>
							<h2 class="m-0" >Interview <br>Q & A</h2>
						</center>
                        </div>
                    </div>
					</a>	
			   </div> <!--End Row -->
			<!-- /primary heading -->
				<!--div class="row">
                    <div class="col-lg-8">
                        <div class="portlet">
                            <div class="portlet-heading">
                                <h3 class="portlet-title text-dark text-uppercase">
                                    Weekly Sales Report
                                </h3>
                                <div class="portlet-widgets">
                                    <a href="javascript:;" data-toggle="reload"><i class="ion-refresh"></i></a>
                                    <span class="divider"></span>
                                    <a data-toggle="collapse" data-parent="#accordion1" href="#portlet1"><i class="ion-minus-round"></i></a>
                                    <span class="divider"></span>
                                    <a href="#" data-toggle="remove"><i class="ion-close-round"></i></a>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div id="portlet1" class="panel-collapse collapse in">
                                <div class="portlet-body">
                                    <div id="morris-bar-example"  style="height: 320px;"></div>

                                    <div class="row text-center m-t-30 m-b-30">
                                        <div class="col-sm-3 col-xs-6">
                                            <h4>$ 126</h4>
                                            <small class="text-muted"> Today's Sales</small>
                                        </div>
                                        <div class="col-sm-3 col-xs-6">
                                            <h4>$ 967</h4>
                                            <small class="text-muted">This Week's Sales</small>
                                        </div>
                                        <div class="col-sm-3 col-xs-6">
                                            <h4>$ 4500</h4>
                                            <small class="text-muted">This Month's Sales</small>
                                        </div>
                                        <div class="col-sm-3 col-xs-6">
                                            <h4>$ 87,000</h4>
                                            <small class="text-muted">This Year's Sales</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div> 

                    </div> 

                    <div class="col-lg-4">
                        <div class="portlet">
                            <div class="portlet-heading">
                                <h3 class="portlet-title text-dark text-uppercase">
                                    Yearly Sales Report
                                </h3>
                                <div class="portlet-widgets">
                                    <a href="javascript:;" data-toggle="reload"><i class="ion-refresh"></i></a>
                                    <span class="divider"></span>
                                    <a data-toggle="collapse" data-parent="#accordion1" href="#portlet2"><i class="ion-minus-round"></i></a>
                                    <span class="divider"></span>
                                    <a href="#" data-toggle="remove"><i class="ion-close-round"></i></a>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div id="portlet2" class="panel-collapse collapse in">
                                <div class="portlet-body">
                                    <div id="morris-line-example" style="height: 200px;"></div>
                                    <div class="row text-center m-t-30">
                                <div class="col-sm-4">
                                    <h4>$ 86,956</h4>
                                    <small class="text-muted"> This Year's Report</small>
                                </div>
                                <div class="col-sm-4">
                                    <h4>$ 86,69</h4>
                                    <small class="text-muted">Weekly Sales Report</small>
                                </div>
                                <div class="col-sm-4">
                                    <h4>$ 948,16</h4>
                                    <small class="text-muted">Yearly Sales Report</small>
                                </div>

                            </div>
                                </div>
                            </div>
                        </div> <!-- /Portlet -->
						<!--
                        <div class="tile-stats white-bg"> 
                            <div class="col-sm-8">
                                <div class="status">
                                <h3 class="m-t-15">61.5%</h3> 
                                <p>US Dollar Share</p>
                            </div> 
                            </div>
                            <div class="col-sm-4 m-t-20">
                                <span class="sparkpie-big"><canvas width="98" height="50" style="display: inline-block; width: 98px; height: 50px; vertical-align: top;"></canvas></span> 
                            </div>
                        </div>
                    </div>
                </div --> <!-- End row -->
<!--                <div class="row">
                    <div class="col-lg-4">

                        <!-- Chat -->
                <!--       <div class="portlet"><!-- /primary heading -->
                <!--            <div class="portlet-heading">
                                <h3 class="portlet-title text-dark text-uppercase">
                                    Chat
                                </h3>
                                <div class="portlet-widgets">
                                    <a href="javascript:;" data-toggle="reload"><i class="ion-refresh"></i></a>
                                    <span class="divider"></span>
                                    <a data-toggle="collapse" data-parent="#accordion1" href="#portlet-3"><i class="ion-minus-round"></i></a>
                                    <span class="divider"></span>
                                    <a href="#" data-toggle="remove"><i class="ion-close-round"></i></a>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div id="portlet-3" class="panel-collapse collapse in">
                                <div class="portlet-body">
                                    <div class="chat-conversation">
                                        <ul class="conversation-list nicescroll">
                                            <li class="clearfix">
                                                <div class="chat-avatar">
                                                    <img src="<?php echo ASSETS;?>img/avatar-2.jpg" alt="male">
                                                    <i>10:00</i>
                                                </div>
                                                <div class="conversation-text">
                                                    <div class="ctext-wrap">
                                                        <i>John Deo</i>
                                                        <p>
                                                            Hello!
                                                        </p>
                                                    </div>
                                                </div>
                                            </li>
                                            <li class="clearfix odd">
                                                <div class="chat-avatar">
                                                    <img src="<?php echo ASSETS;?>img/avatar-3.jpg" alt="Female">
                                                    <i>10:01</i>
                                                </div>
                                                <div class="conversation-text">
                                                    <div class="ctext-wrap">
                                                        <i>Smith</i>
                                                        <p>
                                                            Hi, How are you? What about our next meeting?
                                                        </p>
                                                    </div>
                                                </div>
                                            </li>
                                            <li class="clearfix">
                                                <div class="chat-avatar">
                                                    <img src="<?php echo ASSETS;?>img/avatar-2.jpg" alt="male">
                                                    <i>10:01</i>
                                                </div>
                                                <div class="conversation-text">
                                                    <div class="ctext-wrap">
                                                        <i>John Deo</i>
                                                        <p>
                                                            Yeah everything is fine
                                                        </p>
                                                    </div>
                                                </div>
                                            </li>
                                            <li class="clearfix odd">
                                                <div class="chat-avatar">
                                                    <img src="<?php echo ASSETS;?>img/avatar-3.jpg" alt="male">
                                                    <i>10:02</i>
                                                </div>
                                                <div class="conversation-text">
                                                    <div class="ctext-wrap">
                                                        <i>Smith</i>
                                                        <p>
                                                            Wow that's great
                                                        </p>
                                                    </div>
                                                </div>
                                            </li>
                                        </ul>
                                        <div class="row">
                                            <div class="col-xs-9 chat-inputbar">
                                                <input type="text" class="form-control chat-input" placeholder="Enter your text">
                                            </div>
                                            <div class="col-xs-3 chat-send">
                                                <button type="submit" class="btn btn-info">Send</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div> 
                    </div> -->

                   <!-- <div class="col-lg-4">

                        <!-- TODO -->
                    <!--    <div class="portlet" id="todo-container"><!-- /primary heading -->
                    <!--        <div class="portlet-heading">
                                <h3 class="portlet-title text-dark text-uppercase">
                                    Todo
                                </h3>
                                <div class="portlet-widgets">
                                    <a href="javascript:;" data-toggle="reload"><i class="ion-refresh"></i></a>
                                    <span class="divider"></span>
                                    <a data-toggle="collapse" data-parent="#accordion1" href="#portlet-5" class="" aria-expanded="true"><i class="ion-minus-round"></i></a>
                                    <span class="divider"></span>
                                    <a href="#" data-toggle="remove"><i class="ion-close-round"></i></a>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div id="portlet-5" class="panel-collapse collapse in">
                                <div class="portlet-body todoapp">
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <h4 id="todo-message"><span id="todo-remaining"></span> of <span id="todo-total"></span> remaining</h4> 
                                        </div>
                                        <div class="col-sm-6">
                                            <a href="#" class="pull-right btn btn-primary btn-sm" id="btn-archive">Archive</a>
                                        </div>
                                    </div>

                                    <ul class="list-group no-margn nicescroll todo-list" style="max-height: 275px;" id="todo-list"></ul>

                                     <form name="todo-form" id="todo-form" role="form" class="m-t-20">
                                        <div class="row">
                                            <div class="col-sm-9 todo-inputbar">
                                                <input type="text" id="todo-input-text" name="todo-input-text" class="form-control" placeholder="Add new todo">
                                            </div>
                                            <div class="col-sm-3 todo-send">
                                                <button class="btn-info btn-block btn" type="button" id="todo-btn-submit">Add</button>
                                            </div>
                                        </div>
                                    </form>

                                </div>
                            </div>
                        </div>
                    </div> <!-- end col -->

    <!--            <div class="col-lg-4">

                        <!-- Team-Member -->
    <!--                    <div class="portlet"><!-- /primary heading -->
    <!--                        <div class="portlet-heading">
                                <h3 class="portlet-title text-dark text-uppercase">
                                    Team Members
                                </h3>
                                <div class="portlet-widgets">
                                    <a href="javascript:;" data-toggle="reload"><i class="ion-refresh"></i></a>
                                    <span class="divider"></span>
                                    <a data-toggle="collapse" data-parent="#accordion1" href="#portlet-6" class="" aria-expanded="true"><i class="ion-minus-round"></i></a>
                                    <span class="divider"></span>
                                    <a href="#" data-toggle="remove"><i class="ion-close-round"></i></a>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div id="portlet-6" class="panel-collapse collapse in">
                                <div class="portlet-body">
                                    <ul class="list-group list-group-lg">
                                        <li class="list-group-item b-0">
                                            <a href="#" class=" m-r-10">
                                              <img src="<?php echo ASSETS;?>img/avatar-3.jpg" class="thumb-sm br-radius">
                                            </a>
                                            <span class="pull-right label bg-primary inline m-t-10">CEO</span>
                                            <a href="#">Jonathan Deo</a>
                                        </li>
                                        <li class="list-group-item b-0">
                                            <a href="#" class=" m-r-10">
                                              <img src="<?php echo ASSETS;?>img/avatar-4.jpg" class="thumb-sm br-radius">
                                            </a>
                                            <span class="pull-right label bg-info inline m-t-10">Webdesigner</span>
                                            <a href="#">Doler Perte</a>
                                        </li>
                                        <li class="list-group-item b-0">
                                            <a href="#" class=" m-r-10">
                                              <img src="<?php echo ASSETS;?>img/avatar-5.jpg" class="thumb-sm br-radius">
                                            </a>
                                            <span class="pull-right label bg-warning inline m-t-10">Webdeveloper</span>
                                            <a href="#">Jannie Dvis</a>
                                        </li>
                                        <li class="list-group-item b-0">
                                            <a href="#" class=" m-r-10">
                                              <img src="<?php echo ASSETS;?>img/avatar-6.jpg" class="thumb-sm br-radius">
                                            </a>
                                            <span class="pull-right label bg-pink inline m-t-10">Programmer</span>
                                            <a href="#">Emma Welson</a>
                                        </li>
                                        <li class="list-group-item b-0">
                                            <a href="#" class=" m-r-10">
                                              <img src="<?php echo ASSETS;?>img/avatar-7.jpg" class="thumb-sm br-radius">
                                            </a>
                                            <span class="pull-right label bg-warning inline m-t-10">Webdeveloper</span>
                                            <a href="#">Jannie Dvis</a>
                                        </li>
                                        <li class="list-group-item b-0">
                                            <a href="#" class=" m-r-10">
                                              <img src="<?php echo ASSETS;?>img/avatar-8.jpg" class="thumb-sm br-radius">
                                            </a>
                                            <span class="pull-right label bg-info inline m-t-10">Webdesigner</span>
                                            <a href="#">Petere Husen</a>
                                        </li>
                                        <li class="list-group-item b-0">
                                            <a href="#" class=" m-r-10">
                                              <img src="<?php echo ASSETS;?>img/avatar-9.jpg" class="thumb-sm br-radius">
                                            </a>
                                            <span class="pull-right label bg-warning inline m-t-10">Webdeveloper</span>
                                            <a href="#">John Deo</a>
                                        </li>
                                    </ul>
                                </div> <!-- end portlet-body -->
			</div> <!-- end portlet-collapsed -->
            <!-- Page Content Ends -->
            <!-- ================== -->
<?php $this->load->view('footer1');?>