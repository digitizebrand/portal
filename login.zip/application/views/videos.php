<?php $this->load->view('header1');?>
    <style media="screen">
    .container.gallery-container {
		padding-top:2em;
        background-color: #fff;
        color: #35373a;
        min-height: 100vh;
        box-shadow: 0 8px 15px rgba(0, 0, 0, 0.06);
    }
    .gallery-container h1 {
        text-align: center;
        font-family: 'Droid Sans', sans-serif;
        font-weight: bold;
    }
    .gallery-container p.page-description {
        text-align: center;
        max-width: 800px;
        margin: 25px auto;
        color: #888;
        font-size: 18px;
    }
    .tz-gallery {
        padding: 20px;
    }
    .tz-gallery  div iframe {
        width: 100%;
        // border-radius: 1em;
        margin-bottom: 30px;
        transition: 0.2s ease-in-out;
        box-shadow: 0 2px 3px rgba(0,0,0,0.2);
    }
    .tz-gallery div iframe:hover {
       
        box-shadow: 0 8px 15px rgba(0,0,0,0.3);
    }
    .tz-gallery img {
        border-radius: 4px;
    }
    .baguetteBox-button {
        background-color: transparent !important;
    }
    @media(max-width: 768px) {
        body {
            padding: 0;
        }
        .container.gallery-container {
            border-radius: 0;
        }
    }.#baguetteBox-overlay{
		display:none! important;
	}
	.drive-viewer-toolstrip {
		display: none;
	}
	.text-center {
		text-align: center;
		padding-bottom: 1em;
	}
    </style>
	<div class="container">
	<h2 class="text-center">Important Videos</h2>
</div>
<div class="container gallery-container col-md-10 col-lg-10 col-xs-12 col-md-offset-1">
    <div class="tz-gallery">
        <div class="row">
		<div class="col-md-12 col-lg-12 col-xs-12">
		<?php foreach ($result->result as $row) { ?>
			<div class="col-xs-12 col-md-6" style="padding-right:1.5em">
				<iframe width="100%" height="210" src="<?php echo $row->link;?>" allowfullscreen="allowfullscreen" frameborder="0" style="margin-bottom:0px! important">				
				</iframe>				
				<div style="width: 80px; height: 80px; position: absolute; opacity: 0; 	right: 0px; top: 0px;">
				</div>
				<h4 class="text-center"><?php echo $row->name;?></h4>
            </div>
		<?php }?>
          </div>
		</div>
    </div>
	<div class="clearfix">&nbsp;</div>
</div>
<div class="clearfix">&nbsp;</div>
<?php
include_once ("footer1.php");
 ?>
 <script>
 $(document).ready(function(){
	$(".drive-viewer-toolstrip").html(""); 
 });
 </script>