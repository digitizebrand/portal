<?php $this->load->view('header1');?>
<link href="<?php echo ASSETS;?>css/viewer-datauri.css" media="screen" rel="stylesheet" type="text/css">
  <link href="<?php echo ASSETS;?>css/print.css" media="print" rel="stylesheet" type="text/css">
  <script src="<?php echo ASSETS;?>js/viewer.js" type="text/javascript"></script>
  <script src="<?php echo ASSETS;?>js/templates.js" type="text/javascript"></script>
<div class="container">
	<h2 class="text-center"> Support & Services </h2>
</div>
<div id="Iframe-Master-CC-and-Rs document-viewer" class="set-margin set-padding set-border set-box-shadow center-block-horiz" style="">
	<div style="margin-top:1em" class="hidden-xs">&nbsp;</div>  
		<style>
		.support div{
			margin-bottom:1em;
		}
		</style>
	<div class="col-md-12 col-lg-12 col-sm-12 col-xs-12 support">
		<?php $arr=array(); ?>
		<div class="col-md-offset-2 col-md-8 col-sm-10">
		<p>
			If you can't find a solution to your problems in our knowledgebase, you can submit a ticket by selecting the appropriate department below.</p>
		</div>
		<div class="col-md-4 col-lg-4 col-sm-6 col-xs-6 col-md-offset-2">
			<a><h4><i class="fa fa-envelope"></i> <u>Support</u></h4></a>
			<p>Technical Support ( Domain & Hosting )</p>
		</div>
		<div class="col-md-4 col-lg-4 col-sm-6 col-xs-6 col-md-offset-1">
			<a><h4><i class="fa fa-envelope"></i> <u>Sales</u></h4></a>
			<p>Account Activation Support</p>
		</div>
		<div class="col-md-4 col-lg-4 col-sm-6 col-xs-6 col-md-offset-2">
			<a><h4><i class="fa fa-envelope"></i> <u>Customer Services</u></h4></a>
			<p>Issue with training, infrastructure & other contact Management through this department.</p>
		</div>
		<div class="col-md-4 col-lg-4 col-sm-6 col-xs-6 col-md-offset-1">
			<a><h4><i class="fa fa-envelope"></i> <u>Suggestions</u></h4></a>
			<p> For Improvements and Suggestions	.</p>
		</div>
	</div>
</div>
<?php $this->load->view('footer1');?>
<script type="text/javascript">
  window.currentDocument = DV.load(
    '<?php echo ASSETS;?>js/trump.js', {
      container: '#document-viewer',
    }
  );
</script>