<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="shortcut icon" href="<?php echo DIGITAL_TRAINEE; ?>images/logo.png" />
		<title>Student Login | Digital Trainee</title>
		<link rel="canonical" href="<?php echo current_url(); ?>" />
		<link href="<?php echo DIGITAL_TRAINEE; ?>css/bootstrap.css" rel="stylesheet">
		<link href="<?php echo DIGITAL_TRAINEE; ?>css/style.css" rel="stylesheet">
		<link href="<?php echo DIGITAL_TRAINEE; ?>fonts/stylesheet.css" rel="stylesheet">
		<link href="<?php echo DIGITAL_TRAINEE; ?>css/font-awesome.css" rel="stylesheet">
		<link href="<?php echo DIGITAL_TRAINEE; ?>css/menu.css" rel="stylesheet">
		<link href="<?php echo DIGITAL_TRAINEE; ?>css/anim-load.css" rel="stylesheet">
		<link href="<?php echo DIGITAL_TRAINEE; ?>css/owl.carousel.css" rel="stylesheet">
		<style>
		.row{
			margin-right: 0px;
			margin-left: 0px;
		}
		.error::before{
			content:' ';
		}
		.error{
			color:red;
			
		}
		body{    font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;		}
		</style>
	</head>
<body>
<?php include('menu.php');?>
	<div class="hidden-xs" style="padding-top: 10em;"></div>
	<div class="clearfix">&nbsp;</div>
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="col-lg-6 col-md-6 col-md-offset-3 col-sm-12 col-xs-12 ">
						<?php //print_r($vcode);exit;
						if($vcode->code==SUCCESS_CODE){ ?>
						<div class="panel panel-primary">
						<div class="panel-heading">
							<h4 class="panel-title">Reset Password</h4>
						</div>
						<div class="panel-body">
							<div class="clearfix">&nbsp;</div>
							<form class="form-horizontal" id="reset_password"  method="post" style="padding:10px 20px;">
							<fieldset>
							<div class="form-group">
								<div class="col-sm-11">
								   <p>New Password<sup>*</sup><span class="error" id="resetnewpassword_error"></span></p>
								  <input type="password" class="form-control" name="newpassword" id="resetnewpassword" placeholder="Enter New Password" autocomplete="off" maxlength="20" />
								  <input type="hidden" class="form-control" value="<?php echo $fp_code;?>" name="fp_code" id="fp_code" />
								  <input type="hidden" class="form-control" value="<?php echo $user_id;?>" name="user_id" id="user_id" />
								</div>
							</div>
							<div class="form-group">
								<div class="col-sm-11">
								   <p>Confirm New Password<sup>*</sup><span class="error" id="resetconfirmpassword_error"></span></p>
								  <input type="password" class="form-control" name="resetconfirmpassword" id="resetconfirmpassword" placeholder="Re-enter New Password" autocomplete="off" maxlength="20" />
								</div>
							</div>
							<style>
							.fa-circle {
							  color: #008db8;  
							}
							</style>
							<div class="col-sm-11">
								<p>&nbsp;</p>
								<div class="pull-right">
									<button type="submit" id="reset_btn" class="btn btn-primary">
									<i class="fa fa-undo"></i>
								<b> Reset Password </b></button>
								</div>
								<div id="resertpwddiv"></div>
							</div>
							</fieldset>
						  </form>
						</div>
							<div class="dynamic_message"></div>
						</div>
						<?php }else{ ?>
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mydetails">
							<div class="head">Reset Password - Error</div>
							<div class="clearfix">&nbsp;</div>
							<form class="form-horizontal" id="reset_password"  method="post" style="padding:10px 20px;">
							<fieldset>
							<div class="form-group">
								<div class="col-sm-11">
									<h4><b>Error occured</b> - Invalid Request!</h4>
								</div>
							</div>
							</fieldset>
							</form>
						</div><?php } ?>
                    </div>
                    <div class="clearfix"></div> 
                </div>
                <div class="clearfix"></div> 
			</div>
        <div class="clearfix"></div>             
		</div>
	<div class="clearfix"></div>
<?php $this->load->view('footer'); ?>
<script type="text/javascript">
/*change password validation start*/
var passwordpattern=/^[A-Za-z0-9!@#$%^&*()_]{6,20}$/;
$('#reset_password').on('submit',function(e){
    e.preventDefault();
    str = true;
    $('#resetnewpassword_error,#resetconfirmpassword_error').text('');
    $('#resetnewpassword,#resetconfirmpassword').css('border','');
    var newpassword = $('#resetnewpassword').val();
    var confpassword = $('#resetconfirmpassword').val();
    var baseurl= "<?php echo base_url();; ?>"
    var fpcode = $('#fp_code').val();
    var user_id = $('#user_id').val();
    // var formdetails=JSON.stringify($('#reset_password').serializeObject());
	if(newpassword=='')
    {
      $('#resetnewpassword').css('border','1px solid red');
      $('#resetnewpassword_error').text('Enter New Password');
      str=false;
    }
    /*if(newpassword!='' && !passwordpattern.test(newpassword))
    {
      $('#resetnewpassword').css('border','1px solid red');
      $('#resetnewpassword_error').text('Enter Valid Password with minimum 6 Characters');
      str=false;
    }*/
    if(newpassword!='' &&  (confpassword!=newpassword))
    {
		$('#resetconfirmpassword').css('border','1px solid red');
		$('#resetconfirmpassword_error').text('Entered password not matched');
		str=false;
	}
	if(str==true)
	{
		$('#reset_btn').hide();
        $('#resertpwddiv').html('<img src="<?php echo FRONT_LOADING_IMAGE;?>"/>');
		$.ajax({
			dataType:'JSON',
			method:'POST',
			data:JSON.stringify({'newpassword':newpassword,'confpassword':confpassword,'fp_code':fpcode,"user_id":user_id}),
            url:baseurl+'user/resetpassword',
			success:function(s)
			{
				console.log(s);
				// $('#common_footer_popup').modal('show');
				$('#resertpwddiv').html('');
				// $('.dynamic_title').html('Reset Password');
					switch(s.code)
					{  
						case 200:
							$('.dynamic_message').html('Your password is reset. Please wait we are redirecting to login page.').addClass('alert alert-success');
						break;
						case 204:
						$('#reset_btn').show();
							$('.dynamic_message').html('Entered credentials are invalid').addClass('alert alert-warning');
						break;
						case 301:
						case 422:
						case 575:
						$('#reset_btn').show();
							$('.dynamic_message').html(s.description).addClass('alert alert-danger');
					   break;
					}
					if(s.code==200){setTimeout(function(){window.location="<?php echo base_url(); ?>";},3000);}
					else{setTimeout(function(){
							//$('#common_footer_popup').modal('hide');
						},4000);}	  
			},
			error:function(e){console.log(e);},
		});
    }
    return str;
});
</script>