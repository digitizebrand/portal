<?php $this->load->view('header1');?>
<link href="<?php echo ASSETS;?>css/viewer-datauri.css" media="screen" rel="stylesheet" type="text/css">
  <link href="<?php echo ASSETS;?>css/print.css" media="print" rel="stylesheet" type="text/css">
  <script src="<?php echo ASSETS;?>css/viewer.js" type="text/javascript"></script>
  <script src="<?php echo ASSETS;?>css/templates.js" type="text/javascript"></script>

  <style type="text/css" media="screen">
    body {
      margin: 0;
    }

    h1 {
      font-family: Arial, sans-serif;
      text-align: center;
    }

    #document-viewer {
      margin: 0px auto 500px;
      width: auto;
    }
    @media (min-width: 520px) {
      #document-viewer {
        width: 520px; 
      }
    }
    @media (min-width: 720px) {
      #document-viewer {
        width: 720px;
      }
    }
    @media (min-width: 945px) {
      #document-viewer {
        width: 945px;
      }
    }
    @media (min-width: 1050px) {
      #document-viewer {
        width: 1050px;
      }
    }
  </style>
<div class="container">
	<h2 class="text-center">Sample Resume Formats</h2>
</div>
<style>
/*** Didesweb ***/
/*** Diseño y desarrollo web ***/
/*** http://didesweb.com/ ***/

/*** Reset ***/

* {
  padding: 0;
  margin: 0;
  border: 0;
}
ul,
ol { list-style-type: none; }

/*** Other ***/

.main {
  width: 80%;
  margin: 0 10%;
  margin-top: 100px;
  position: absolute;
  z-index: 2;
  text-align: center;
}


/*** Navbar ***/

.navbar_nav {
  height: 50px;
  background-color: #F44336;
  position: absolute;
  z-index: 3;
}

.navbar_nav,
.menu_a { width: 100%; }

.menu_li,
.menu_a { display: inline-block;color:white }

.menu_li {
  width: 20%;
  float: left;
  opacity: 0.8;
  text-align: center;
  height: 50px;
}

.menu_a { padding: 16px 0; }

.menu_li:hover, .menu_a:hover {
    background-color: #03a9f4;
    opacity: 1;
    color: white;
    padding-bottom: 1em;
}

a:hover, a:focus {
	color: white;
	text-decoration: none;
}
.active{
 background-color: #03A9F4;
  opacity: 1;
}

#menu-acces {
  display: none;
  width: 100%;
  position: relative;
  text-align: center;
}

.menu_open:after {
  content: "";
  display: table;
}
@media only screen and (max-width: 480px) {

#menu-acces { display: block; }

.navbar_ul { display: none; }

.menu_li {
  width: 100%;
  position: relative;
  opacity: 1;
}

.menu_open { height: auto; }
}
menu_li a {
  text-decoration: none;
  color: white;
} 

	</style>
<nav class="col-lg-12 col-md-12 col-sm-12 col-xs-12 bg-fb">
	<!--a href="#" id="menu-acces" class="menu_a">OPEN THE MENU</a-->
	<ul class="">
	<?php if($result->code==SUCCESS_CODE){
		$i=1;
		foreach($result->result as $row){	?>
		<li class="menu_li <?php echo ($i==1)?'active':'' ?>" id="<?php echo $row->path; ?>">
			<a class="menu_a" href="javascript:void(0)"><?php echo $row->name; ?></a>
		</li>
		<?php $i++; }  } ?>
	</ul>
</nav>
<div class="set-margin set-padding set-border set-box-shadow center-block-horiz" style="">
<div style="margin-top:1em" class="">&nbsp;</div>    
  <div id="document-viewer" class="embed-responsive embed-responsive-4by3" style="height:20em! important">
	<iframe id="ifr" class="col-lg-12 col-xs-12" src="<?php echo $result->result[0]->path; ?>"> 
     
    </iframe>
		
  </div>
</div>
<?php $this->load->view('footer1');?>
<script>
	$('.menu_li').click(function(){
		var id=this.id;
		$('.menu_li').removeClass('active');
		$(this).addClass('active');
		$("#ifr").attr('src',id);
	});
</script>
<script type="text/javascript">
  window.currentDocument = DV.load(
    '<?php echo ASSETS;?>css/trump.js', {
      container: '#document-viewer',
    }
  );
</script>