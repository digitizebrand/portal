<?php 
$this->load->view('header1');?>
<div class="container">
	<h2 class="text-center">Digital Marketing Course Study Material</h2>
</div>

<div id="Iframe-Master-CC-and-Rs" class="set-margin set-padding set-border set-box-shadow center-block-horiz" style="">
<div style="margin-top:1em" class="hidden-xs">&nbsp;</div>    
  <div class="embed-responsive embed-responsive-4by3" >
    <iframe id="ifr" class="col-lg-12 col-xs-12" src="
<?php echo base_url().$result->result[0]->name?>"> 
      <p style="font-size: 110%;"><em><strong>ERROR: </strong>  
An &#105;frame should be displayed here but your browser version does not support &#105;frames. </em>Please update your browser to its most recent version and try again.</p>
    </iframe>
    
  </div>
</div>
<?php $this->load->view('footer1');?>