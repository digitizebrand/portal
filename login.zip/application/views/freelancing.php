<?php $this->load->view('header1');?>
<div class="container">
	<h2 class="text-center">Latest Digital Marketing Syllabus</h2>
</div>
<style>
/*** Didesweb ***/
/*** Diseño y desarrollo web ***/
/*** http://didesweb.com/ ***/

/*** Reset ***/

* {
  padding: 0;
  margin: 0;
  border: 0;
}
ul,
ol { list-style-type: none; }

/*** Other ***/

.main {
  width: 80%;
  margin: 0 10%;
  margin-top: 100px;
  position: absolute;
  z-index: 2;
  text-align: center;
}


/*** Navbar ***/

.navbar_nav {
  height: 50px;
  background-color: #F44336;
  position: absolute;
  z-index: 3;
}

.navbar_nav,
.menu_a { width: 100%; }

.menu_li,
.menu_a { display: inline-block;color:white }

.menu_li {
  width: 16%;
  float: left;
  opacity: 0.8;
  text-align: center;
  height: 50px;
}

.menu_a { padding: 16px 0; }

.menu_li:hover, .menu_a:hover {
    background-color: #03a9f4;
    opacity: 1;
    color: white;
    padding-bottom: 1em;
}

a:hover, a:focus {
	color: white;
	text-decoration: none;
}
.active{
 background-color: #03A9F4;
  opacity: 1;
}

#menu-acces {
  display: none;
  width: 100%;
  position: relative;
  text-align: center;
}

.menu_open:after {
  content: "";
  display: table;
}
@media only screen and (max-width: 480px) {

#menu-acces { display: block; }

.navbar_ul { display: none; }

.menu_li {
  width: 100%;
  position: relative;
  opacity: 1;
}

.menu_open { height: auto; }
}
menu_li a {
  text-decoration: none;
  color: white;
} 

	</style>


<nav class="col-lg-12 col-md-12 col-sm-12 col-xs-12 bg-fb">
	<!--a href="#" id="menu-acces" class="menu_a">OPEN THE MENU</a-->
	<ul class="">
	<?php if($result->code==SUCCESS_CODE){
		$i=1;
		foreach($result->result as $row){	?>
		<li class="menu_li <?php echo ($i==1)?'active':'' ?>" id="<?php echo base_url().$row->path; ?>">
			<a class="menu_a" href="javascript:void(0)"><?php echo $row->name; ?></a>
		</li>
		<?php $i++; }  } ?>
	</ul>
</nav>
<div id="Iframe-Master-CC-and-Rs" class="set-margin set-padding set-border set-box-shadow center-block-horiz" style="">
<div style="margin-top:1em" class="hidden-xs">&nbsp;</div>    
  <div class="embed-responsive embed-responsive-4by3" >
    <iframe id="ifr" class="col-lg-12 col-xs-12" src="<?php echo base_url().$result->result[0]->path; ?>"> 
      <p style="font-size: 110%;"><em><strong>ERROR: </strong>  
An &#105;frame should be displayed here but your browser version does not support &#105;frames. </em>Please update your browser to its most recent version and try again.</p>
    </iframe>
    
  </div>
</div>
<?php $this->load->view('footer1');?>
<script>
	$('.menu_li').click(function(){
		var id=this.id;
		$('.menu_li').removeClass('active');
		$(this).addClass('active');
		$("#ifr").attr('src',id);
	});
</script>
<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-36251023-1']);
  _gaq.push(['_setDomainName', 'jqueryscript.net']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
<script>
/*** Didesweb ***/
/*** Diseño y desarrollo web ***/
/*** http://didesweb.com/ ***/

$(document).ready(function(){
	responsive_menu = $('.navbar_ul');
	$('#menu-acces').on('click', function(e) {
		e.preventDefault();
		responsive_menu.slideToggle();
	});
	$(window).resize(function(){
		var obtener_ancho = $(this).width(); 
		if(obtener_ancho > 480 && responsive_menu.is(':hidden')) {
			responsive_menu.removeAttr('style');
		}
	}); 
	$('nav li').on('click', function(e) {                
		var obtener_ancho = $(window).width();
		if(obtener_ancho < 480 ) {
			responsive_menu.slideToggle(); 
		}
	});
});
</script>