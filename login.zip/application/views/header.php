<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Student Login Registration</title>
  </head>
  <body>
<?php 
if(defined('BASE_URL')){
	
}else{
$url_details=$_SERVER['HTTP_HOST'];
$url_details.=str_replace(basename($_SERVER['SCRIPT_NAME']),'',$_SERVER['SCRIPT_NAME']);/*For Getting the project(Hosting Name)*/
$base_url ='https://'.$url_details;
define('TEAM_IMG_PATH',$base_url.'images/team/');
define('BASE_URL', 'https://digitaltrainee.com/');
define('DEVELOPER_NAME',' Digitizebrand Hub (India) Pvt Ltd');
define('DEVELOPER_LINK','http://digitizebrand.com');
define('PROJECT_NAME','Digitizebrand Hub');
define('CSS_PATH',$base_url.'css/');
}
?>
<?php include"css.php";
        include("menu.php");
?>

