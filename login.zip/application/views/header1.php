<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="A fully featured admin theme which can be used to build CRM, CMS, etc.">
        <meta name="author" content="<?php echo SITE_TITLE;?>">
		<link rel="canonical" href="<?php echo current_url();?>" />
        <link rel="shortcut icon" href="https://digitaltrainee.com/images/logo.png" />

        <title>Student - Dashboard | Digital Trainee</title>

        <!-- Google-Fonts -->
        <link href='https://fonts.googleapis.com/css?family=Source+Sans+Pro:100,300,400,600,700,900,400italic' rel='stylesheet'>

        <!-- Bootstrap core CSS -->
        <link href="<?php echo ASSETS;?>css/bootstrap.min.css" rel="stylesheet">
        <link href="<?php echo ASSETS;?>css/bootstrap-reset.css" rel="stylesheet">

        <!--Animation css-->
        <link href="<?php echo ASSETS;?>css/animate.css" rel="stylesheet">

        <!--Icon-fonts css-->
        <link href="<?php echo ASSETS;?>font-awesome/css/font-awesome.css" rel="stylesheet" />
        <link href="<?php echo ASSETS;?>ionicon/css/ionicons.min.css" rel="stylesheet" />

        <!--Morris Chart CSS -->
        <link rel="stylesheet" href="<?php echo ASSETS;?>morris/morris.css">

        <!-- sweet alerts -->
        <link href="<?php echo ASSETS;?>sweet-alert/sweet-alert.min.css" rel="stylesheet">

        <!-- Custom styles for this template -->
        <link href="<?php echo ASSETS;?>css/style.css" rel="stylesheet">
        <link href="<?php echo ASSETS;?>css/helper.css" rel="stylesheet">
        <link href="<?php echo ASSETS;?>css/style-responsive.css" rel="stylesheet" />
		
        <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
<!--[if lt IE 9]>
  <script src="js/html5shiv.js"></script>
  <script src="js/respond.min.js"></script>
<![endif]-->

<!--script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','../../../www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-62751496-1', 'auto');
  ga('send', 'pageview');

</script-->

    </head>
	<body>

        <!-- Aside Start-->
        <aside class="left-panel">
            <!-- brand -->
            <div class="logo">
                <a href="https://digitaltrainee.com/" class="logo-expanded">
                    <img src="https://digitaltrainee.com/images/logo.png" style="width:50%" alt="Digital Trainee">
                </a>
            </div>
            <!-- / brand -->        
            <!-- Navbar Start -->
            <nav class="navigation">
                <ul class="list-unstyled">
                    <li class="has-submenu <?php echo (isset($D))?'active':'';?>"><a href="<?php echo base_url('user/dashboard');?>"><i class="ion-home"></i> <span class="nav-label">Dashboard</span></a>                 
                    </li>
					<li class="has-submenu <?php echo (isset($S))?'active':'';?>"><a href="<?php echo base_url('user/syllabus');?>"><i class="fa fa-file-pdf-o"></i> <span class="nav-label">Syllabus</span></a>   
                    </li>
					<li class="has-submenu <?php echo (isset($SM))?'active':'';?>"><a href="<?php echo base_url('user/study-material');?>"><i class="glyphicon glyphicon-list-alt"></i> <span class="nav-label">Study Material</span></a>   
                    </li>
					<li class="has-submenu <?php echo (isset($FL))?'active':'';?>"><a href="<?php echo base_url('user/freelancing');?>"><i class="fa fa-tags"></i> <span class="nav-label">Freelancing</span></a>   
                    </li>					
					<li class="has-submenu <?php echo (isset($VD))?'active':'';?>"><a href="<?php echo base_url('user/videos');?>"><i class="glyphicon glyphicon-play-circle"></i> <span class="nav-label">Videos</span></a>   
                    </li>
					<li class="has-submenu <?php echo (isset($AS))?'active':'';?>"><a href="<?php echo base_url('user/assignments');?>"><i class="glyphicon glyphicon-tasks"></i> <span class="nav-label">Assignments</span></a>   
                    </li>
					<li class="has-submenu <?php echo (isset($DR))?'active':'';?>">
					
							<?php $active_link= 'javascript:void(0)';$alert="Oops! Your account is not fully activated. Please contact your trainer. Thank you";
								  if($this->session->userdata('payment')==1){
									$active_link= base_url('user/domain-registration');
									$alert="";
									}
								  ?> 
							<a href="<?php echo $active_link;?>" <?php if($alert!=''){ ?>onclick="alert('<?php echo $alert?>')" <?php }
							 ?>><i class="glyphicon glyphicon-globe"></i> <span class="nav-label">Domain Registration</span></a>   
                    </li>
					<li class="has-submenu <?php echo (isset($RE))?'active':'';?>"><a href="<?php echo base_url('user/resume');?>"><i class="glyphicon glyphicon-file"></i> <span class="nav-label">Resume Formats</span></a>   
                    </li>
					<li class="has-submenu <?php echo (isset($PS))?'active':'';?>">
							<?php $active_link= 'javascript:void(0)';$alert="Oops! Your account is not fully activated. Please contact your trainer. Thank you";
								  if($this->session->userdata('payment')==1){
									$active_link= base_url('user/placements');
									$alert="";
									}
								  ?> 
							<a href="<?php echo $active_link;?>" <?php if($alert!=''){ ?>onclick="alert('<?php echo $alert?>')" <?php }
							 ?>><i class="glyphicon glyphicon-briefcase"></i> <span class="nav-label">Placement Alerts</span></a>   
                    </li>
					<li class="has-submenu <?php echo (isset($IQ))?'active':'';?>"><a href="<?php echo base_url('user/interview-questions-and-answers');?>"><i class="fa fa-question-circle"></i> <span class="nav-label">Interview Q & A</span></a>   
                    </li>
					<!--
					<li class="has-submenu"><a href="#"><i class="fa fa-bell-o"></i> <span class="nav-label">Notifications</span></a>   
                    </li>
					<li class="has-submenu"><a href="#"><i class="glyphicon glyphicon-tasks"></i> <span class="nav-label">Assignments</span></a>   
                    </li-->
					<li class="has-submenu"><a href="<?php echo base_url('user/user_logout');?>"><i class="glyphicon">&#xe017;</i> <span class="nav-label">Logout</span></a>   
                    </li>
					<!--li class="has-submenu"><a href="#"><i class="ion-flask"></i> <span class="nav-label">UI Elements</span></a>
                        <ul class="list-unstyled">
                            <li><a href="typography.html">Typography</a></li>
                            <li><a href="buttons.html">Buttons</a></li>
                            <li><a href="icons.html">Icons</a></li>
                            <li><a href="panels.html">Panels</a></li>
                            <li><a href="tabs-accordions.html">Tabs &amp; Accordions</a></li>
                            <li><a href="modals.html">Modals</a></li>
                            <li><a href="bootstrap-ui.html">BS Elements</a></li>
                            <li><a href="progressbars.html">Progress Bars</a></li>
                            <li><a href="notification.html">Notification</a></li>
                            <li><a href="sweet-alert.html">Sweet-Alert</a></li>
                        </ul>
                    </li>
                    <li class="has-submenu"><a href="#"><i class="ion-settings"></i> <span class="nav-label">Components</span></a>
                        <ul class="list-unstyled">
                            <li><a href="grid.html">Grid</a></li>
                            <li><a href="portlets.html">Portlets</a></li>
                            <li><a href="widgets.html">Widgets</a></li>
                            <li><a href="nestable-list.html">Nesteble</a></li>
                            <li><a href="calendar.html">Calendar</a></li>
                        </ul>
                    </li>
                    <li class="has-submenu"><a href="#"><i class="ion-compose"></i> <span class="nav-label">Forms</span></a>
                        <ul class="list-unstyled">
                            <li><a href="form-elements.html">General Elements</a></li>
                            <li><a href="form-validation.html">Form Validation</a></li>
                            <li><a href="form-advanced.html">Advanced Form</a></li>
                            <li><a href="form-wizard.html">Form Wizard</a></li>
                            <li><a href="form-editor.html">WYSIWYG Editor</a></li>
                            <li><a href="code-editor.html">Code Editors</a></li>
                            <li><a href="form-uploads.html">Multiple File Upload</a></li>
                            <li><a href="image-crop.html">Image Crop</a></li>
                        </ul>
                    </li>
                    <li class="has-submenu"><a href="#"><i class="ion-grid"></i> <span class="nav-label">Data Tables</span></a>
                        <ul class="list-unstyled">
                            <li><a href="tables.html">Basic Tables</a></li>
                            <li><a href="table-datatable.html">Data Table</a></li>
                        </ul>
                    </li>
                    <li class="has-submenu"><a href="#"><i class="ion-stats-bars"></i> <span class="nav-label">Charts</span></a>
                        <ul class="list-unstyled">
                            <li><a href="morris-chart.html">Morris Chart</a></li>
                            <li><a href="chartjs.html">Chartjs</a></li>
                            <li><a href="flot-chart.html">Flot Chart</a></li>
                            <li><a href="rickshaw-chart.html">Rickshaw Chart</a></li>
                            <li><a href="c3-chart.html">C3 Chart</a></li>
                            <li><a href="other-chart.html">Other Chart</a></li>
                        </ul>
                    </li>

                    <li class="has-submenu"><a href="#"><i class="ion-email"></i> <span class="nav-label">Mail</span></a>
                        <ul class="list-unstyled">
                            <li><a href="inbox.html">Inbox</a></li>
                            <li><a href="email-compose.html">Compose Mail</a></li>
                            <li><a href="email-read.html">View Mail</a></li>
                        </ul>
                    </li>

                    <li class="has-submenu"><a href="#"><i class="ion-location"></i> <span class="nav-label">Maps</span></a>
                        <ul class="list-unstyled">
                            <li><a href="gmap.html"> Google Map</a></li>
                            <li><a href="vector-map.html"> Vector Map</a></li>
                        </ul>
                    </li>
                    <li class="has-submenu"><a href="#"><i class="ion-document"></i> <span class="nav-label">Pages</span></a>
                        <ul class="list-unstyled">
                            <li><a href="profile.html">Profile</a></li>
                            <li><a href="timeline.html">Timeline</a></li>
                            <li><a href="invoice.html">Invoice</a></li>
                            <li><a href="contact.html">Contact-list</a></li>
                            <li><a href="login.html">Login</a></li>
                            <li><a href="register.html">Register</a></li>
                            <li><a href="recoverpw.html">Recover Password</a></li>
                            <li><a href="lock-screen.html">Lock Screen</a></li>
                            <li><a href="blank.html">Blank Page</a></li>
                            <li><a href="404.html">404 Error</a></li>
                            <li><a href="404_alt.html">404 alt</a></li>
                            <li><a href="500.html">500 Error</a></li>
                        </ul>
                    </li -->
                </ul>
            </nav>
                
        </aside>
        <!-- Aside Ends-->
        <!--Main Content Start -->
        <section class="content">
            
            <!-- Header -->
            <header class="top-head container-fluid">
                <button type="button" class="navbar-toggle pull-left">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>               
                <!-- Search 
                <form role="search" class="navbar-left app-search pull-left hidden-xs" style="width:20em">
                  <input type="text" placeholder="Search..." class="form-control">
                </form -->                
                <!-- Left navbar 
                <nav class=" navbar-default hidden-xs" role="navigation">
                    <ul class="nav navbar-nav">
                        <li class="dropdown">
                          <a data-toggle="dropdown" class="dropdown-toggle" href="#">English <span class="caret"></span></a>
                            <ul role="menu" class="dropdown-menu">
                                <li><a href="#">German</a></li>
                                <li><a href="#">French</a></li>
                                <li><a href="#">Italian</a></li>
                                <li><a href="#">Spanish</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Files</a></li>
                        <li><a href="http://coderthemes.com/velonic_3.0/frontend/" target="_blank">Frontend</a></li>
                    </ul>
                </nav>
				-->                
                <!-- Right navbar -->
                <ul class="list-inline navbar-right top-menu top-right-menu">  
                    <!-- mesages -->  
                    <!--li class="dropdown">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <i class="fa fa-envelope-o "></i>
                            <span class="badge badge-sm up bg-purple count">4</span>
                        </a>
                        <ul class="dropdown-menu extended fadeInUp animated nicescroll" tabindex="5001">
                            <li>
                                <p>Messages</p>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="pull-left"><img src="<?php echo ASSETS;?>img/avatar-2.jpg" class="img-circle thumb-sm m-r-15" alt="img"></span>
                                    <span class="block"><strong>John smith</strong></span>
                                    <span class="media-body block">New tasks needs to be done<br><small class="text-muted">10 seconds ago</small></span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="pull-left"><img src="<?php echo ASSETS;?>img/avatar-3.jpg" class="img-circle thumb-sm m-r-15" alt="img"></span>
                                    <span class="block"><strong>John smith</strong></span>
                                    <span class="media-body block">New tasks needs to be done<br><small class="text-muted">3 minutes ago</small></span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="pull-left"><img src="<?php echo ASSETS;?>img/avatar-4.jpg" class="img-circle thumb-sm m-r-15" alt="img"></span>
                                    <span class="block"><strong>John smith</strong></span>
                                    <span class="media-body block">New tasks needs to be done<br><small class="text-muted">10 minutes ago</small></span>
                                </a>
                            </li>
                            <li>
                                <p><a href="inbox.html" class="text-right">See all Messages</a></p>
                            </li>
                        </ul>
                    </li>
                    <!-- /messages -->
                    <!-- Notification 
                    <li class="dropdown">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <i class="fa fa-bell-o"></i>
                            <span class="badge badge-sm up bg-pink count">3</span>
                        </a>
                        <ul class="dropdown-menu extended fadeInUp animated nicescroll" tabindex="5002">
                            <li class="noti-header">
                                <p>Notifications</p>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="pull-left"><i class="fa fa-user-plus fa-2x text-info"></i></span>
                                    <span>New user registered<br><small class="text-muted">5 minutes ago</small></span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="pull-left"><i class="fa fa-diamond fa-2x text-primary"></i></span>
                                    <span>Use animate.css<br><small class="text-muted">5 minutes ago</small></span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="pull-left"><i class="fa fa-bell-o fa-2x text-danger"></i></span>
                                    <span>Send project demo files to client<br><small class="text-muted">1 hour ago</small></span>
                                </a>
                            </li>
                            
                            <li>
                                <p><a href="#" class="text-right">See all notifications</a></p>
                            </li>
                        </ul>
                    </li>
                    <!-- /Notification -->
<style>
.dropdown-backdrop {
    position: relative;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    z-index: 990;
}
</style>
                    <!-- user login dropdown start-->
                    <li class="dropdown text-center">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <!--<img alt="" src="<?php echo ASSETS;?>img/avatar-2.jpg" class="img-circle profile-img thumb-sm"-->
                            <span class="username">							
							<?php echo ucfirst($this->session->userdata('user_name'));?></span> <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu extended pro-menu fadeInUp animated" tabindex="5003" style="overflow: hidden; outline: none;">
                            <li><a href="<?php echo base_url('user/profile');?>"><i class="fa fa-briefcase"></i>Profile</a></li>
                            <!--li><a href="#"><i class="fa fa-cog"></i> Settings</a></li>
                            <li><a href="#"><i class="fa fa-bell"></i> Friends <span class="label label-info pull-right mail-info">5</span></a></li-->
                            <li><a href="<?php echo base_url('user/user_logout');?>"><i class="fa fa-sign-out"></i> Log Out</a></li>
                        </ul>
                    </li>
                    <!-- user login dropdown end -->       
                </ul>
                <!-- End right navbar -->
            </header>
            <!-- Header Ends -->
			<div class="modal fade" id="common_footer_popup" style="top:25%" role="dialog">
				<div class="modal-dialog modal-sm">
				  <div class="modal-content">
					<div class="modal-header">
					  <button type="button" class="close" data-dismiss="modal">&times;</button>
					  <h4 class="modal-title dynamic_title"></h4>
					</div>
					<div class="modal-body">
						<p class="dynamic_message"></p>
					</div>
					<div class="modal-footer">
					  <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
					</div>
				  </div>
				</div>
			  </div>
			 <!-- POPup model code End -->