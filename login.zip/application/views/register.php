<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="shortcut icon" href="<?php echo DIMG_PATH; ?>images/logo.png" />
		<title>Student Login | Digital Trainee</title>
		<link rel="canonical" href="<?php echo current_url(); ?>" />
		<link href="<?php echo DIMG_PATH; ?>css/bootstrap.css" rel="stylesheet">
		<link href="<?php echo DIMG_PATH; ?>css/style.css" rel="stylesheet">
		<link href="<?php echo DIMG_PATH; ?>fonts/stylesheet.css" rel="stylesheet">
		<link href="<?php echo DIMG_PATH; ?>css/font-awesome.css" rel="stylesheet">
		<link href="<?php echo DIMG_PATH; ?>css/menu.css" rel="stylesheet">
		<link href="<?php echo DIMG_PATH; ?>css/anim-load.css" rel="stylesheet">
		<link href="<?php echo DIMG_PATH; ?>css/owl.carousel.css" rel="stylesheet">
		<style>
		.row{
			margin-right: 0px;
			margin-left: 0px;
		}
		.error{
			color:red;
		}
		body{    font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;		}
		</style>
	</head>
<body>
<?php include('menu.php');?>
	<span style="background-color:red;">
	<div class="container hidden-xs" style="padding-top:10em"></div><!-- container class is used to centered  the body of the browser with some decent width-->
<div>	
	<div class="row" style="margin-right:0px;"><!-- row class is used for grid system in Bootstrap-->
        <div class="col-md-4 col-xs-10 col-xs-offset-1 col-md-offset-1">
            <h3 class="text-center">Already Enrolled Candidates</h3>
            <div class="login-panel panel panel-primary">
                <div class="panel-heading">
                    <h3 class="panel-title">Login</h3>
                </div>
                <?php
              $success_msg= $this->session->flashdata('success_msg');
              $error_msg= $this->session->flashdata('error_msg');

                  if($success_msg){
                    ?>
                    <div class="alert alert-success">
                      <?php echo $success_msg; ?>
                    </div>
                  <?php
                  }
                  if($error_msg){
                    ?>
                    <div class="alert alert-danger">
                      <?php echo $error_msg; ?>
                    </div>
                    <?php
                  }
                  ?>
                <div class="panel-body">
					<div class="logindiv">
                    <form role="form" method="post" action="<?php echo base_url('user/login_user'); ?>">
                        <fieldset>
                            <div class="form-group">
                                <input class="form-control" placeholder="E-mail" name="user_email" id="username" type="email" autofocus >
                            </div>
                            <div class="form-group">
                                <input class="form-control" placeholder="Password" name="user_password" id="password" type="password" value="" >
                            </div>
							<input class="btn btn-lg btn-primary btn-block" type="submit" value="LOGIN" id="login" name="login" />
                        </fieldset>
                    </form>
                    </div>
						<div class="dynamic_message"></div>
						<div class="clearfix">&nbsp;</div>
						<div class="form-group">
							<label><a style="color: #0d497d;font-size: 1em;padding-left: .5em;font-weight: bold;"  data-toggle="tab" id="forgothref" href="#forgotpassword"> Forgot Password? </a></label>
						</div>
						<div class="form group" id="forgotpassworddiv" style="display:none">
						<form id="forgotForm">
							<label><span style="color:red;font-size: 0.9em;" class="error" id="forgotinput_error"></span></label>
							<input class="form-control" name="forgotinput" id="forgotinput" Placeholder="Enter Registered E-mail id" type="text" /><br/>
							<button class="btn btn-primary" id="btn_fp"><i class="fa fa-envelope"></i> Send Link </button>
							<div class="" style="display:inline" id="loading_image_fp"></div>
						</form>
						</div>
                <!--center><b>Not registered ?</b> <br></b><a href="<?php echo base_url('user'); ?>">Register here</a></center><!--for centered text-->

                </div>
            </div>
        </div><div class="col-md-4 col-xs-10 col-xs-offset-1 col-md-offset-1"><!--col-md-4 is used to create the no of colums in the grid also use for medimum and large devices-->
                <h3 class="text-center">Enrollment Form/Registration Form</h3>
              <div class="login-panel panel panel-primary">
                    
                  <div class="panel-heading">
                      <h3 class="panel-title">Registration</h3>
                  </div>
				<div class="panel-body">
				  <?php
				  $error_msg1=$this->session->flashdata('error_msg1');
                  $success_msg1=$this->session->flashdata('success_msg1');
                  
				  if($success_msg1){
                    ?>
                    <div class="alert alert-success">
                      <?php echo $success_msg1; ?>
                    </div>
                  <?php
                  }
                  if($error_msg1){
                    ?>
                    <div class="alert alert-danger">
                      <?php echo $error_msg1; ?>
                    </div>
                    <?php
                  }
                  ?>
	
					<form role="form" method="post" action="<?php echo base_url('user/register'); ?>">
                          <fieldset>
                              <div class="form-group">
                                  <input class="form-control" placeholder="Name" id="username1" name="user_name" type="text" autofocus >
                              </div>

                              <div class="form-group">
                                  <input class="form-control" placeholder="E-mail" id="email" name="user_email" type="email" autofocus >
                              </div>
							   <div class="form-group">
                                  <input class="form-control" placeholder="Mobile No" id="mobile" name="user_mobile" type="text" pattern="[789][0-9]{9}" value="" >
                              </div>
							  <div class="form-group">
								<select name="branch" class="form-control"  id="branch" >
									<option value="">Select Branch (Select One)</option>
								<?php if($branches->code==SUCCESS_CODE){
									foreach($branches->result as $row){
									?>
										<option value="<?php echo $row->id ?>"><?php echo ucwords($row->name)?></option>
									
									<?php
									}
								} ?>
								</select>
							  </div>
							<div class="form-group">  
								<select name="batch" class="form-control" id="sel1" type="select" >
									<option value="">Select Batch (Select One)</option>
									<?php if($batches->code==SUCCESS_CODE){
									foreach($batches->result as $row){
									?>
										<option value="<?php echo $row->id ?>"><?php echo $row->name;?></option>
									<?php
									}
								} ?>	
								</select>
							</div>
							<div class="form-group input-group date" id='datetimepicker1'>  
								<input type='text' name="date" id="datepicker" placeholder="Batch Start Date" class="form-control" />
								<span class="input-group-addon">
									<span class="glyphicon glyphicon-calendar"></span>
								</span>
							</div>
							<div class="form-group">
								<select name="trainer" class="form-control" id="trainer" type="select" >
									<option value="">Select Trainer </option>
									<?php if($trainer->code==SUCCESS_CODE){
									foreach($trainer->result as $row){
									?>
										<option value="<?php echo $row->id ?>"><?php echo $row->name;?></option>
									<?php
									}
								} ?>
								</select>
							</div>
							<div class="form-group">		  
								<select name="bd" class="form-control"  id="bd" >
									<option value="">Admission By (Select One)</option>
								<?php if($bds->code==SUCCESS_CODE){
									foreach($bds->result as $row){
								?>
									<option value="<?php echo $row->id ?>"><?php echo ucwords($row->name)?></option>
								<?php
									}
								} ?>
								</select>
							</div>
							<div class="form-group">		  
								<select name="purpose" class="form-control"  id="purpose" >
									<option value=""> Select Course Purpose </option>
									<option value="1"> Job </option>
									<option value="2"> Business </option>
									<option value="3"> Freelancing </option>
								</select>
							</div>
							<div class="form-group">
								<input class="form-control" placeholder="Password" name="user_password" id="password1" type="password" value="" >
							</div>
							<div class="form-group">
								<span class="error" id="confirm_password_error">
								</span>
								<input class="form-control" placeholder="Confirm Password" name="user_password1" id="confirm_password" type="password" value=""/>
							</div>
							<input class="btn btn-lg btn-primary" type="submit" id="register" value="REGISTER" name="register" />
							<input class="btn btn-lg btn-danger" type="reset" id="reset" value="RESET" name="reset" />
						</fieldset>
					</form>
				</div>
			</div>
		</div>
	</div>
	</span>
	</div>
  <?php include 'footer.php';?>
<script src="<?php echo JS_PATH; ?>date-time-picker.min.js"></script>
<script>
$(document).ready(function(){
$(function () {
	$('#datepicker').dateTimePicker({
		format:'dd-MM-yyyy'
	});
});
    $("#login").click(function(){
	//alert("clicked");	
		var username = $("#username").val();
		var password=$("#password").val();
		if(username==''){
		$('#username').css('border','1px solid red');
		$('#password').css('border','1px solid red');
		return false;		
		}
		if(password==''){
		$('#password').css('border','1px solid red');
		return false;	
		}

        });
    });
</script>
<script>
$(document).ready(function(){
    $("#register").click(function(){
	//alert("clicked");
		var flag=true;
		var username = $("#username1").val();
		// alert(username);
		var email=$("#email").val();
		var mobile=$("#mobile").val();
		var branch=$("#branch").val();
		var sel1=$("#sel1").val();
		var bd=$("#bd").val();
		var datepicker=$("#datepicker").val();
		var password=$("#password1").val();
		var confirm_password=$("#confirm_password").val();
		var trainer=$("#trainer").val();
		var purpose=$("#purpose").val();
		$('#username1, #email, #mobile, #branch, #sel1, #password1, #confirm_password, #trainer, #purpose, #bd, #datepicker').css('border','1px solid #ccc');
		if(username==''){$('#username1').css('border','1px solid red');flag=false;}
		if(email==''){$('#email').css('border','1px solid red');flag=false;}
		if(mobile==''){$('#mobile').css('border','1px solid red');flag=false;}
		if(trainer==''){
		$('#trainer').css('border','1px solid red');
		 flag=false;		
		}
		if(branch==''){
		$('#branch').css('border','1px solid red');
		 flag=false;		
		}
		if(sel1==''){
		$('#sel1').css('border','1px solid red');
		 flag=false;		
		}
		if(bd==''){
		$('#bd').css('border','1px solid red');
		 flag=false;		
		}
		if(datepicker==''){
		$('#datepicker').css('border','1px solid red');
		 flag=false;		
		}		
		if(purpose==''){ $('#purpose').css('border','1px solid red');flag=false; }
		if(password==''){
		$('#password1').css('border','1px solid red');
		 flag=false;		
		}
		if(confirm_password==''){
		$('#confirm_password').css('border','1px solid red');
		 flag=false;	
		} 
		// if(password!='' && confirm_password!=''){
			if(password != confirm_password) {
				flag=false;
				$('#confirm_password').css('border','1px solid red');
				$('#confirm_password_error').html('Confirm passoword mismatch');
			}
		// }
		// alert(flag);
		return flag;
        });
    });
	$('#confirm_password').keyup(function(){
		var password=$('#password1').val();
		var confirm_password=$('#confirm_password').val();
		// alert(password+ confirm_password);
		if(password!='' && confirm_password!=''){
			if(password != confirm_password) {
				flag=false;
				$('#confirm_password').css('border','1px solid red');
				$('#confirm_password_error').html('Confirm passoword mismatch');
			}else{
				$('#confirm_password').css('border','1px solid green');
				$('#confirm_password_error').html('');
			}
		}
	});
</script>
  </body>
</html>
<script>
	$('#forgotForm').submit(function(e){
		e.preventDefault();
		// alert('ss');
		str=true;
		$('#forgotinput').css('border','');
		$('#forgotinput_error').text('');
		var emailpattern = /^[a-zA-Z0-9][a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
		var forgotinput=$('#forgotinput').val();
		if(forgotinput=='')
		{
			$('#forgotinput').css('border','1px solid red');
			$('#forgotinput_error').text('Enter email id');
			str=false;
		}
		if(forgotinput!='' && !emailpattern.test(forgotinput))
		{
			$('#forgotinput').css('border','1px solid red');
			$('#forgotinput_error').text('Enter valid email id');
			str=false;
		}
		if(str==true)
		{
			$('#btn_fp').hide();$('#btn_back_login').hide();
			$('#loading_image_fp').html('<img src="<?php echo FRONT_LOADING_IMAGE;?>"/>');
			$.ajax({
				dataType:'JSON',
				type:'post',
				data:JSON.stringify({'email':forgotinput}),
				url:"<?php echo base_url(); ?>user/forgotpassword",
				success:function(s)
				{
					console.log(s);
					$('#loading_image_fp').html('');
					$('#btn_fp').show();
					$('#btn_fp').attr('disabled','true');
					switch(s.code)
					{
						case 200:
							$('.dynamic_message').html(s.description).addClass('alert alert-success');
							setTimeout(function(){window.location=window.location.href;},4000);
						break;
						case 204:
						case 301:
						case 422:
						case 575:
							$('.dynamic_message').html(s.description).addClass('alert alert-danger');
							$('#btn_fp').show();
						break;
					}
				  //setTimeout(function(){$('#common_footer_popup').modal('hide');},4000);
				},
				error:function(e){console.log(e);},
				
			});
		}
	   return str;
	});
	$('#forgotpassworddiv').hide();
	$('#forgothref').click(function(){
		$('#forgotpassworddiv').show('slow');
		$('.logindiv').hide('slow');
		$('.panel-title').html('Forgot Password');
	});
</script>