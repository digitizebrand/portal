<style> @charset "utf-8";
/* CSS Document */
/* sticky button */ 
/* Fees Structure */ 
#feedback { height: 0px;width: 85px;position: fixed;right: 0em; top: 67%;z-index: 1000;transform: rotate(-90deg);-webkit-transform: rotate(-90deg);-moz-transform: rotate(-90deg);-o-transform: rotate(-90deg);filter: progid:DXImageTransform.Microsoft.BasicImage(rotation=3);}

#feedback a {
  display: block;
  background:#fa7073;
  height: 44px;
  padding-top: 5px;
  line-height:16px;
  text-align: center;
  color: #fff;
  font-family: Arial, sans-serif;
  font-size: 17px;
  font-weight: bold;
  text-decoration: none;
}
#feedback a:hover {background:#00495d;}
a:focus, a:hover {color: white;text-decoration: none;}
a{transition: all 0.5s ease-out;text-decoration: none;color: #f9f6f6;}
/* Enquiry */
#feedback1 {
  height: 0px;
  width: 95px;
  position: fixed;
  right: -0.3em;
  top: 50%;
  z-index: 1000;
  transform: rotate(-90deg);
  -webkit-transform: rotate(-90deg);
  -moz-transform: rotate(-90deg);
  -o-transform: rotate(-90deg);
  filter: progid:DXImageTransform.Microsoft.BasicImage(rotation=3);
}
#feedback1 a {display: block;background:#fa7073;height: 44px;padding-top: 9px;text-align: center;color: #fff;font-family: Arial, sans-serif;font-size: 17px;font-weight: bold;text-decoration: none;}
#feedback1 a:hover {background:#00495d;}
#login11 {
 height: 0px;width: 85px;position: fixed;right: 0em; top: 80%;z-index: 1000;transform: rotate(-90deg);-webkit-transform: rotate(-90deg);-moz-transform: rotate(-90deg);-o-transform: rotate(-90deg);filter: progid:DXImageTransform.Microsoft.BasicImage(rotation=3);}
#login11 a {
display: block;
    background: #fa7073;
    height: 44px;
    padding-top: 0px;
    text-align: center;
    color: #fff;
    font-family: Arial, sans-serif;
    font-size: 16px;
    font-weight: bold;
    text-decoration: none;
}
#login11 a:hover {background:#00495d;}
</style>
	<!--div id="login11">
      <a href="https://digitaltrainee.com/students/" id="login1" data-toggle="modal">Login Signup</a>
    </div-->
 <div id="feedback">
      <a href="#" data-target="#myModal" id="feesstructure" data-toggle="modal">Fees Structure</a>
    </div>
  <div id="feedback1">
      <a href="#" data-target="#myModal" id="enquiry" data-toggle="modal">Enquiry</a>
    </div>
<footer>
  <div class="container-fluid footertop">
    <div class="container">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 padding0">
        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 module" data-animated="fadeInLeft">
          <h4>About Us</h4>
          <p><img src="<?php echo DIGITAL_TRAINEE; ?>images/borderbottom.jpg" alt="borderbottom"/></p>
          <p align="justify">Digital Trainee is an initiative for those who are ambitious in the field of Digital Marketing. We are educating you into digital marketing because we think that you have excellent ability of making it big. The field of practical marketing is, and goes to be the future, and we feel that people have a terrific risk of creating it huge. The handiest element they require is the need to prevail and the favored talents. 
We at digital Trainee might take care of the abilities component through our education and also attempt to inculcate the seeds of achievement in them.</p>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 module" data-animated="fadeInRight">
          <h4>Contact Us</h4>
          <p><img src="<?php echo DIGITAL_TRAINEE; ?>images/borderbottom.jpg" alt="borderbottom"/></p>
          <p><i class="fa  fa-map-marker"></i> Nal Stop Branch <br>Digital Trainee,<br/> 
            2nd Floor, 7/3, Manohar Apartment, <br/>Opposite To PNG Jewellers, Near Nisarg Hotel, Nal stop, Karve road, Erandwane,<br/> Pune, Maharashtra 411004 </p>
          <p><i class="fa fa-phone-square"></i> <a href="tel:+918237774545" onclick="ga('send', 'event', 'Phonecall', 'click/touch', 'Phonenumber');">8237774545</a>, <a href="tel:+918983765316">8983765316</a></p>
          <p><i class="fa fa-envelope"></i> <a href="mailto:Info@digitaltrainee.com" onclick="ga('send', 'event', 'email', 'click/touch', 'email');">Info@digitaltrainee.com</a></p>
          <h4>Follow Us On</h4>
          <p><img src="<?php echo DIGITAL_TRAINEE; ?>images/borderbottom.jpg" alt="borderbottom"/></p>
          <p> <a href="https://www.facebook.com/digitaltrainee/" target="_blank"><img src="<?php echo DIGITAL_TRAINEE; ?>images/facebook.png" alt="fb-icon"/></a> <a href="https://plus.google.com/u/0/+DigitalTrainee" target="_blank"><img src="<?php echo DIGITAL_TRAINEE; ?>images/googleplus.png" alt="google-icon"/></a> <a href="https://www.youtube.com/channel/UCUGquecFWUKalo-KsZ-vfOA" target="_blank"><img src="<?php echo DIGITAL_TRAINEE; ?>images/youtube.png" alt="yputube-icon"/></a> <a href="https://twitter.com/_Digitaltrainee" target="_blank"><img src="<?php echo DIGITAL_TRAINEE; ?>images/twitter.png" alt="twitter-icon"/></a> <a href="https://www.linkedin.com/company/digital-trainee" target="_blank"><img src="<?php echo DIGITAL_TRAINEE; ?>images/linkdin.png" alt="linkdin-icon"/></a> <a href="https://in.pinterest.com/digitaltrainees/" target="_blank"><img src="<?php echo DIGITAL_TRAINEE; ?>images/pin.png" alt="pinterest-icon"/></a> <a href="<?php echo base_url(); ?>sitemap.xml" target="_blank"><img src="<?php echo DIGITAL_TRAINEE; ?>images/xml2.png" alt="sitemap-icon"/></a> </p>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 fotterform" data-animated="fadeInLeft">
          <h4>Enquire Us</h4>
          <p><img src="<?php echo DIGITAL_TRAINEE; ?>images/borderbottom.jpg" alt="borderbottom"/></p>
         <form id="newsletter" action="<?php echo base_url(); ?>php/contact_quote_newsletter.php" method="post">
            <div class="row">
              <div class="col-lg-12">
                <div class="form-group">
                  <input type="text"  id="newslettername"  name="newslettername" data-validation-engine="validate[required,custom[onlyLetterSp]]" placeholder="Enter Your Name" required/>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <div class="form-group">
                  <input type="text" pattern="[789][0-9]{9}"  id="newsletterphone"  name="newsletterphone"  placeholder="Enter Your Phone No." required/>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <div class="form-group">
                  <input type="text" id="newsletteremail" name="newsletteremail" data-validation-engine="validate[required,custom[email]]"placeholder="Enter Your Email Id." required/>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-12">
                <div class="form-group">
                  <select class="form-control" name="course" id="course" style="width:100%; height:35px;" required>
                    <option>Select Nearest Branch</option>
                    <option value="1">Nal Stop</option>
                    <option value="2">Viman Nagar</option>
                    <option value="3">Pimpri Chinchwad (PCMC)</option>
                    </select>
                </div>
              </div>
            </div>
            <br>
            <div class="row">
              <div class="col-lg-12">
                <div class="form-group">
                     <button type="submit" class="btn btn-danger  hvr-sweep-to-right">Submit</button>
                  <!--<input type="button" value="Submit"/>-->
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  <div class="container-fluid lastfooter">
    <div class="container">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <p class="pull-left" data-animated="bounceIn">Copyright <i class="fa fa-copyright"></i> <?php echo date('Y'); ?>. All Rights Reserved.</p>
        <p align="center" data-animated="bounceIn">Designed and Developed By : <a href="<?php echo DEVELOPED_BY_LINK; ?>" target="_blank">DigitizeBrand Hub (India) Pvt Ltd.</a></p>
      </div>
    </div>
  </div>
  <div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
        <form id="newsletter" action="<?php echo base_url(); ?>include/download1.php" method="post">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Download</h4>
            </div>
            <div class="modal-body" >
             
                <input  type="text"  id="newslettername"  name="newslettername"  placeholder="Enter Your Name" style="width:90%;  height:35px;" required/><br>
                <input type="email" id="newsletteremail" name="newsletteremail"  placeholder="Enter Your Email Id." style="width:90%;  height:35px;" required/> <br>  
				<input type="hidden" id="hidden" name="parameter" value="1" />
                <input type="text" pattern="[789][0-9]{9}"  id="newsletterphone"  name="newsletterphone"  placeholder="Enter Your Phone No." style="width:90%; height:35px;" required/>
                <br/>
                <label style="padding-top:15px;"></label>
                  <select class="form-control" name="course" id="course" style="width:90%;  height:35px;" required>
                    <option>Select Location</option>
                    <option value="1">Nal Stop</option>
                    <option value="2">Viman Nagar</option>
                    <option value="3">Pimpri Chinchwad (PCMC)</option>
                  </select>
                <br/>
            </div>
             <!--<input type="button" value="Submit"/>-->
            <div class="modal-footer">
                <button type="submit" class="btn btn-danger  hvr-sweep-to-right" value="submit" name="submit">Download</button>
            </div>
        </form>
    </div>
</div></div>
</footer>
<script src="<?php echo DIGITAL_TRAINEE; ?>js/jquery.min.js"></script> 
<script src="<?php echo DIGITAL_TRAINEE; ?>js/bootstrap.js"></script> 
<script src="<?php echo DIGITAL_TRAINEE; ?>js/menu.js"></script> 
<script src="<?php echo DIGITAL_TRAINEE; ?>js/owl.carousel.min.js"></script> 
<script src="<?php echo DIGITAL_TRAINEE; ?>js/animload.min.js"></script> 
<script src="<?php echo DIGITAL_TRAINEE; ?>js/back-to-top.js"></script> 
<script src="<?php echo DIGITAL_TRAINEE; ?>js/jquery.validationEngine.js"></script>
<script src="<?php echo DIGITAL_TRAINEE; ?>js/languages/jquery.validationEngine-en.js"></script>
<script>
/* $(document).ready(function() {
        $('.owl-carousel01').owlCarousel({
        loop:true,
        nav:true,
        dots:true,
        responsiveClass:true,
        autoWidth:false,
        autoplay:true,
          autoplayTimeout:3000,
          autoplayHoverPause:true,
        items: 1,
        smartSpeed:800
      })
      
       $('.owl-carousel02').owlCarousel({
        loop:true,
        nav:false,
        dots:true,
        responsiveClass:true,
        autoWidth:false,
        autoplay:true,
          autoplayTimeout:3000,
          autoplayHoverPause:true,
        items: 1,
        smartSpeed:800
      })  
});*/
$(document).ready(function(){
 jQuery("#newsletter").validationEngine('attach', {promptPosition : "topRight", scroll: false,maxErrorsPerField:1,
    'custom_error_messages': {
        '#newslettername' : {
            'required': {
            'message': "Please enter name"
            },
            'custom[onlyLetterSp]': {
            'message': "Please enter letters only"
            },
        },
            
        '#newsletteremail' : {
            'required': {
            'message': "Please enter email"
            },
            'custom[email]': {
            'message': "Invalid email address"
            },
        },
        '#newsletterphone' : {
            'required': {
            'message': "Please enter phone"
            },
            'custom[phone]': {
            'message': "Please enter valid phone"
            },            
        },  
  
    }
    ,onValidationComplete: function(form, status){ 
    var stat = 0;  
    var SITEURL = jQuery("#themeurl").val();
    var DIRURL = jQuery("#template_directory_uri").val();
        if(status==true){
    jQuery.ajax({
    method: "POST",
    async: false,
    //url: SITEURL+"/captchacheck.php",
    data: jQuery('#formIDquickcontact').serialize()
    })
    .done(function (response) {    //alert("response : "+response);
            var responseback = response;
            if (responseback == 0) {            
             stat =0 ;
            } else {
                stat=1;  
            }
    });
    
        if (stat == 0) {
       // jQuery('.cptValMsg')('<div style="background:#e09f9f;color:rgb(255, 0, 0);font-weight:bold;padding:5px;text-align:left;width:80%;">Re-Captcha is required</div>');
        jQuery('.cptValMsg').show();
    return false;
    } else {
    return true;
    }
    }}
    });  
});
</script>
<!--
<form action="<?php echo base_url(); ?>payment/form_process.php" method="POST">
 <div class="modal fade" data-keyboard="false" data-backdrop="static" id="payment-modal" tabindex="-1" role="dialogue" >
<div class="modal-dialogue modal-sm">
  <div class="modal-content">
    <div class="modal-header">
      <button class="close" data-dismiss="modal">&times</button>
      <h4 class="modal-title" style=" color:style="color:5984bf">Payment Form</h4>
         </div>
         <div class="modal-body">
          
         <input type="hidden" name="txnid" value="<?php echo $txnid=time().rand(1000,99999); ?>" />
                     <div class="form-group">
                        <label for="cardNumber">
                            Name</label>
                        <div class="input-group">
                            <input type="text" class="form-control" name="firstname" id="cardNumber" placeholder="Enter Your Name"
                                required autofocus />
                            <span class="input-group-addon"><span class="glyphicon glyphicon-user"></span></span>
                        </div>
                    </div>
         <div class="form-group">
                        <label for="cardNumber">
                            Email</label>
                        <div class="input-group">
                            <input type="email" name="email" class="form-control" id="cardNumber" placeholder="Enter Your Email"
                                required autofocus />
                            <span class="input-group-addon"><span class="glyphicon glyphicon-envelope"></span></span>
                        </div>
                    </div>
         <div class="form-group">
                        <label for="cardNumber">
                            Mobile</label>
                        <div class="input-group">
                            <input type="text" name="phone" pattern="[789][0-9]{9}" class="form-control" id="cardNumber" placeholder="Enter Your Number"
                                required autofocus />
                            <span class="input-group-addon"><span class="glyphicon glyphicon-phone"></span></span>
                        </div>
                    </div>
          <div class="form-group">
                        <label for="cardNumber">
                            </label>
                        <div class="input-group">
                            <select class="form-control" name="amount" id="cardNumber" placeholder="Enter Your Number"
                                required autofocus >
                                    <option value="" disabled>--SELECT PAYMENT--</option>
  
                                  <option value="3060">REGISTRATION FEES (3000/- + 2%) </option>
                                  <option value="11220">REGISTRATION + FIRST INSTALLMENT FEES (11,000/- + 2%)</option>
                                    <option value="19890">FULL FEES (19,500/- + 2%)</option>
                                      <option value="8160">FIRST INSTALLMENT FEES (8,000/- + 2%)</option>
                                        <option value="9690">SECOND INSTALLMENT FEES (9,500/- + 2%)</option>
                            </select>
                            <span class="input-group-addon"><span class="fa fa-inr"></span></span>                           
                        </div>
                        <label><i style="color:red">Note: 2% will be extra charged for payment gateway.</i></label>
                    </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-primary" name="submit"  >Pay Now</button>
      <button class="btn btn-danger" data-dismiss="modal">close</button>

    </div>
  </div>

</div>
</div>
</form>
-->
<form action="<?php echo base_url(); ?>php/reminder.php" method="POST">
 <div class="modal fade"  id="login-modal" >
<div class="modal-dialogue modal-sm">
  <div class="modal-content">
    <div class="modal-header">
      <button class="close" data-dismiss="modal">&times;</button>
      <h4 class="modal-titlee" style="color:5984bf">Reminder Form</h4>
         </div>
         <div class="modal-body">
          
         <div class="form-group">  
          <label for="form-control" >Name:</label>
          <input placeholder="Enter Full name" typee="text"  name="name" style="width:90%;  height:35px;" required>
        </div>
        <div class="form-group">  
          <label for="form-control" >Email:</label>
          <input placeholder="Enter Email" typee="email"  name="email" style="width:90%;  height:35px;" required>
        </div>
        <div class="form-group">  
          <label for="form-control" >Phone.</label>
          <input placeholder="Enter Mobile Number" type="text"  name="phone" pattern="[789][0-9]{9}" style="width:90%;  height:35px;" required>
        </div>
        <div class="form-group">  
      <label for="sel1">Select Batch(select one):</label>
      <select name="batch" class="form-control" id="sel1" type="select" style="width:90%;  height:35px;" value="select" required>
        <option >08 AM- 9:30 AM</option>
        <option >10 AM- 12 PM</option>
        <option >09 AM- 11 AM</option>
        <option >12 PM- 02 PM</option>
        <option >04 PM- 06 PM</option>
        <option >07 PM- 09 PM</option>
        <option >10:30AM - 2:30PM (only Sunday)</option>
      </select>
        </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-primary" name="submit"  >send</button>
      <button class="btn btn-primary" data-dismiss="modal">close</button>
    </div>
  </div>
</div>
</div>
</form>
</body>
</html>
<script>
$('#feesstructure').click( function(){
	$('#hidden').val(1);
});
$('#enquiry').click( function(){
	$('#hidden').val(2);
});
</script>