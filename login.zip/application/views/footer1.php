
            <!-- Footer Start -->
            <footer class="footer">
				<center>
					<a href="<?php echo DEVELOPED_BY_LINK;?>">Designed and Developed By - <?php echo DEVELOPED_BY;?></a>
				<center>

            </footer>
            <!-- Footer Ends -->



        </section>
        <!-- Main Content Ends -->
        


        <!-- js placed at the end of the document so the pages load faster -->
        <script src="<?php echo ASSETS;?>js/jquery.js"></script>
        <script src="<?php echo ASSETS;?>js/bootstrap.min.js"></script>
        <script src="<?php echo ASSETS;?>js/modernizr.min.js"></script>
        <script src="<?php echo ASSETS;?>js/pace.min.js"></script>
        <script src="<?php echo ASSETS;?>js/wow.min.js"></script>
        <script src="<?php echo ASSETS;?>js/jquery.scrollTo.min.js"></script>
        <script src="<?php echo ASSETS;?>js/jquery.nicescroll.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS;?>chat/moment-2.2.1.js"></script>

        <!-- Counter-up -->
        <script src="<?php echo ASSETS;?>js/waypoints.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS;?>js/jquery.counterup.min.js" type="text/javascript"></script>

        <!-- EASY PIE CHART JS -->
        <script src="<?php echo ASSETS;?>easypie-chart/easypiechart.min.js"></script>
        <script src="<?php echo ASSETS;?>easypie-chart/jquery.easypiechart.min.js"></script>
        <script src="<?php echo ASSETS;?>easypie-chart/example.js"></script>


        <!--C3 Chart-->
        <script src="<?php echo ASSETS;?>c3-chart/d3.v3.min.js"></script>
        <script src="<?php echo ASSETS;?>c3-chart/c3.js"></script>

        <!--Morris Chart-->
        <script src="<?php echo ASSETS;?>morris/morris.min.js"></script>
        <script src="<?php echo ASSETS;?>morris/raphael.min.js"></script>

        <!-- sparkline --> 
        <script src="<?php echo ASSETS;?>sparkline-chart/jquery.sparkline.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS;?>sparkline-chart/chart-sparkline.js" type="text/javascript"></script> 

        <!-- sweet alerts -->
        <script src="<?php echo ASSETS;?>sweet-alert/sweet-alert.min.js"></script>
        <script src="<?php echo ASSETS;?>sweet-alert/sweet-alert.init.js"></script>

        <script src="<?php echo ASSETS;?>js/jquery.app.js"></script>
        <!-- Chat -->
        <script src="<?php echo ASSETS;?>js/jquery.chat.js"></script>
        <!-- Dashboard -->
        <script src="<?php echo ASSETS;?>js/jquery.dashboard.js"></script>

        <!-- Todo -->
        <script src="<?php echo ASSETS;?>js/jquery.todo.js"></script>
        <script type="text/javascript">
        /* ==============================================
             Counter Up
             =============================================== */
            jQuery(document).ready(function($) {
                $('.counter').counterUp({
                    delay: 100,
                    time: 1200
                });
            });
        </script>
    

    </body>

<!-- Mirrored from coderthemes.com/velonic_3.0/admin/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 18 May 2018 06:50:21 GMT -->
</html>
<script>
//----------------------------------------
// Breadcrumbs
//----------------------------------------
$('.breadcrumbs li a').each(function(){
    var breadWidth = $(this).width();
    if($(this).parent('li').hasClass('active') || $(this).parent('li').hasClass('first')){
    } else {

        $(this).css('width', 75 + 'px');

        $(this).mouseover(function(){
            $(this).css('width', breadWidth + 'px');
        });
        $(this).mouseout(function(){
            $(this).css('width', 75 + 'px');
        });
    }
});
</script>