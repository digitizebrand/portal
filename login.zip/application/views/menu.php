<?php $base_url='https://digitaltrainee.com/'; ?><style>
.containerbg{background:#545151;}
.alert-danger2 {
    background-color: #fa7073;border-color: #ebccd1;font-size:16px;padding:2px 10px 2px 5px;
}
.alert2 {border: 1px solid transparent;border-radius: 4px;}
.downloadheading{background: #f97073;padding: 10px;cursor: pointer;border-radius:5px;padding-bottom:8px;padding-top:8px;box-shadow:0px 0px 4px 1px black;}
</style>
<div class="mobcta"><a href="https://api.whatsapp.com/send?phone=917276572728&text=Hi,%20I%20need%20assistance%20regarding%20the%20course"><i class="fa fa-whatsapp"></i><a href="tel:+918983765316"><i class="fa fa-phone"></i></a> <a href="mailto:info@digitaltrainee.com" class="searcher"><i class="fa fa-envelope"></i></a> <a data-toggle="modal" data-target="#myModal" class=""><i class="fa  fa-download"> </i> Syllabus</a></div>
<header class="header" style="    background-color: rgba(21,45,89);">
  <div class="container-fluid">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 padding0">
          <div class="hidden-lg  clearfix hidden-md col-sm-12 col-xs-12 padding0">
			<span class="col-sm-6">
				<span  class="pull-left alert2 alert-danger2"><i class="fa fa-bell" style="color:white"></i> <marquee width="90%" direction="left" ><a style="font-size:16px" href="<?php //echo BASE_URL; ?>event-page">New branch open at PCMC. Batch start from 4<sup>th</sup> June</a></marquee>
				</span>
			</span>
			<div class="clearfix">&nbsp;</div>
		  </div>
          <div class="col-lg-2 col-md-2 col-sm-2 col-xs-8 padding0 logo" data-animated="fadeInLeft"> 
			<a href="<?php echo $base_url; ?>"><img src="<?php echo $base_url; ?>images/logo.png" alt="Logo" class="img-responsive"/></a> 
		  </div>
          <div class="col-lg-10 col-md-10 col-sm-10 col-xs-4 padding0">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 hidden-xs">
              <p class="pull-right topcall" style="display: inline;" data-animated="fadeInRight">
				<span class="col-sm-6">
				<span  class="pull-left alert2 alert-danger2"><i class="fa fa-bell"></i> <marquee width="90%" direction="left" ><a style="font-size:16px" href="javascript:void(0)">New Branch Open at Pimpri Chinchwad (PCMC). Batch start from 4<sup>th</sup> June</a></marquee>
				</span>
				</span>
				<span class="pull-right">
				<span><a href="tel:+918983765316"  onclick="ga('send', 'event', 'Phonecall', 'click/touch', 'Phonenumber');"><i class="fa fa-phone-square"></i> 8983765316</a></span> <a data-toggle="modal" data-target="#myModal" class="downloadheading" onclick="ga('send', 'event', 'download', 'click/touch', 'download');" ><span class="calltoaction"><i class="fa fa-download"></i> Syllabus</span></a></span></p>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 padding0">
              <nav class="navbar" data-animated="fadeInRight">
                <div class="wsmenuexpandermain slideRight"><a id="navToggle" class="animated-arrow slideLeft" href="#"><span></span></a></div>
                <div class="wsmenucontent overlapblackbg"></div>
                <nav class="wsmenu slideLeft clearfix">
                  <ul class="mobile-sub wsmenu-list">
                    <li><a href="<?php echo $base_url; ?>"   class="active">HOME</a> </li>
                    <li><a href="<?php echo $base_url; ?>about-us">About us</a>
						<ul class="wsmenu-submenu">
							<li><a href="<?php echo $base_url; ?>about-us">About us</a>
							<li><a href="<?php echo $base_url; ?>our-team">Our Team</a>
						</ul>
					</li>
                    <li><a href="#.">Courses <!--span class="arrow"></span--></a>
                      <ul class="wsmenu-submenu">
                        <li ><a data-toggle="collapse" data-target="#demo" href="#"><font color="#000">Digital Marketing<span class="arrow"></span> </font></a></li>
                        <div id="demo" class="collapse">
                        <li><a href="<?php echo $base_url; ?>digital-marketing-training-in-pune">• Digital Marketing Training </a></li>
                        
                        <li><a href="<?php echo $base_url; ?>advanced-seo-training-pune">• Advanced SEO Training</a></li>
                        <li><a href="<?php echo $base_url; ?>social-media-marketing-training-pune">• SMO/SMM Training</a></li>
                        <li><a href="<?php echo $base_url; ?>sem-ppc-training-in-pune">• SEM (PPC) Training</a></li>
                        <li><a href="<?php echo $base_url; ?>accelerate-your-existing-career-in-digital-marketing">• Boost Existing Career</a></li>
                        <li><a href="<?php echo $base_url; ?>corporate-practical-digital-marketing-training">• Corporate Digital Training</a></li>
                        </div>
                        <!--li><a href="<?php echo $base_url; ?>practical-php-training-in-pune"><font color="#000">Practical PHP Training</font></a></li-->
                        <li><a href="<?php echo $base_url; ?>web-designing-training-in-pune"><font color="#000">Web Designing Training</font></a></li>
                        <li><a href="<?php echo $base_url; ?>graphics-designing-training-in-pune"><font color="#000">Graphics Designing Training</font></a></li>
                        
                      </ul> 
                      </li>
                     <li><a href="<?php echo $base_url; ?>candidate-work">Candidates Work</a></li>
                      <li><a href="#.">Placement <!--span class="arrow"></span--></a>
                      <ul class="wsmenu-submenu">
                        <li><a href="<?php echo $base_url; ?>our-placements"><font color="#000">Our Placements</font></a></li>
                     </li>
                         <li><a href="<?php echo $base_url; ?>placements-companies"><font color="#000">Placements Companies</font></a></li>
                     </ul></li>
                    <li><a href="#.">Why Choose Us?<!--span class="arrow"></span--></a>
                  <ul class="wsmenu-submenu">
                      <li><a href="<?php echo $base_url; ?>digital-trainee-reviews"><font color="#000">Reviews and Testimonials</font></a></li>
                        <li><a href="<?php echo $base_url; ?>why-choose-digital-marketing-course-with-us"><font color="#000">Why Choose Us?</font></a></li>
                     </li>
                         <li><a href="<?php echo $base_url; ?>faq"><font color="#000">FAQ</font></a></li>
                         
                         <li><a href="<?php echo $base_url; ?>gallery"><font color="#000">Gallery </font></a>
                      
                    </li>
                     </ul></li>
                    <li><a href="<?php echo $base_url; ?>knowledge/" target="_blank">Knowledge</a> </li>
                    <li><a href="<?php echo $base_url; ?>contact-us">CONTACT</a> </li>
                  </ul>
                </nav>
              </nav>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>
</header>
<style>
.breadcrumb a {transition: all 0.5s ease-out;text-decoration: none;color: #3a3535;}
</style>