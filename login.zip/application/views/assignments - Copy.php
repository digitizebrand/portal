<?php $this->load->view('header1');?>
<style>
.table{background:}
.nav.nav-tabs>li.active>a, .tabs-vertical-env .nav.tabs-vertical li.active>a {
    border: 0;
    background-color: #fff;
    border-top: 2px solid #2cc322! important;
}
</style>
<div class="container">
	<h2 class="text-center">Upload Your Assignments</h2>
</div>
<div class="container">
	<div class="col-md-12 col-xs-12 col-lg-12 col-sm-12">
		<div class="col-md-2 col-xs-2 col-lg-2 col-sm-2 col-md-offset-9 col-xs-offset-9 col-lg-offset-9">
			<button class="btn btn-warning pull-right" type="button" id="mybtn" data-toggle="modal" data-target="#myModal">View Submitted Assignments</button>
		</div>
	</div>
</div>
<div class="container">
  <!-- Trigger the modal with a button -->
  <!-- Modal -->
	<div class="modal fade " id="myModal" role="dialog">
			<div class="modal-dialog" style="width: 94%;">
			
			  <!-- Modal content-->
			  <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12 modal-content">
				<div class="modal-header">
				  <button type="button" class="close" data-dismiss="modal">&times;</button>
				  <h4 class="modal-title text-center">View Uploaded Assignments</h4>
				</div>
				<div class="modal-body col-lg-12 col-md-12 col-xs-12 col-sm-12">
					  <div class="container" style="padding-left: 0px;margin-left: 0px;padding-right: 0px;margin-right: 0px;">
						  <ul class="nav nav-tabs ">
							<li class="active col-lg-6 col-md-6 col-sm-6 col-xs-6  text-center"><a data-toggle="tab" href="#home">Google Adwords</a></li>
							<li class="col-lg-6 col-md-6 col-sm-6 col-xs-6 text-center"><a data-toggle="tab" href="#menu1">Social Media</a></li>
						  </ul>
					  <div class="tab-content" style="width:100%;padding: 0px;">
						<div id="home" class="tab-pane fade in active">
							<div class="col-md-4 col-xs-12 col-sm-4 col-lg-4">
									<h3 class="text-center">Campaign</h3>
								  <div class="col-md-12 col-lg-12 col-xs-12 padding0">
									<?php $i=0; 
									if($result1->code==SUCCESS_CODE){
									foreach ($result1->result as $row) { ?>
										<div class="col-xs-12 col-md-12" style="padding-bottom: 15px;">						
												<img src="<?php echo ASSIMG.$row->image;?>" style="width:100%;height:15em">
													<br><br>
												<button class="btn btn-warning pull-right btn1" id="<?php echo $row->id;?>">Delete Image</button>
												<br>
												<br>
										</div>
									<?php $i++;}}else{ ?>
									<div class="col-xs-12 col-md-12" style="padding-bottom: 15px;">						
												<p class="alert alert-danger">You haven't submitted Google Adwords Campaign Assignment</p>
										</div>
									<?php } ?>
								</div>			  
							</div>
							<div class="col-md-4 col-xs-12 col-sm-4 col-lg-4">
									<h3 class="text-center">Adgroup</h3>
								  <div class="col-md-12 col-lg-12 col-xs-12">
									<?php $i=100;
									if($result2->code==SUCCESS_CODE){
									foreach ($result2->result as $row) { ?>
										<div class="col-xs-12 col-md-12" style="padding-bottom: 15px;">
												<img src="<?php echo ASSIMG.$row->image;?>" style="width:100%;height:15em">
													<br><br>
												<button class="btn btn-warning pull-right btn1" id="<?php echo $row->id;?>">Delete Image</button>
												<br>
												<br>
										</div>
									<?php $i++;}}else{ ?>
									<div class="col-xs-12 col-md-12" style="padding-bottom: 15px;">						
												<p class="alert alert-danger">You haven't submitted Google Adwords Adgroup Assignment</p>
										</div>
									<?php } ?>
								</div>			  
							</div>
							<div class="col-md-4 col-xs-12 col-sm-4 col-lg-4">
									<h3 class="text-center">Adcopy</h3>
									<?php $i=200;
									if($result3->code==SUCCESS_CODE){
										foreach ($result3->result as $row) { ?>
										<div class="col-xs-12 col-md-12" style="padding-bottom:1em">
												<img src="<?php echo ASSIMG.$row->image;?>" style="width:100%;height:15em">
													<br><br>
												<button class="btn btn-warning pull-right btn1" id="<?php echo $row->id;?>">Delete Image</button>
												<br>
												<br>
										</div>
									<?php $i++;}}else{ ?>
									<div class="col-xs-12 col-md-12" style="padding-bottom: 15px;">						
												<p class="alert alert-danger">You haven't submitted Google Adwords Adcopy Assignment</p>
										</div>
									<?php } ?>
							</div>
						</div>
						<div id="menu1" class="tab-pane fade">
						  <div class="col-md-4 col-xs-12 col-sm-4 col-lg-4">
									<h3 class="text-center">Campaign</h3>
								  <div class="col-md-12 col-lg-12 col-xs-12 padding0">
									<?php $i=300;
									if($result4->code==SUCCESS_CODE){
									foreach ($result4->result as $row) { ?>
										<div class="col-xs-12 col-md-12" style="padding-bottom: 15px;">						
												<img src="<?php echo ASSIMG.$row->image;?>" style="width:100%;height:15em">
													<br><br>
												<button class="btn btn-warning pull-right btn1" id="<?php echo $row->id;?>">Delete Image</button>
												<br>
												<br>
										</div>
									<?php $i++;}}else{ ?>
									<div class="col-xs-12 col-md-12" style="padding-bottom: 15px;">						
												<p class="alert alert-danger">You haven't submitted Social Media Campaign Assignment</p>
										</div>
									<?php } ?>
								</div>			  
							</div>
							<div class="col-md-4 col-xs-12 col-sm-4 col-lg-4">
									<h3 class="text-center">Adgroup</h3>
								  <div class="col-md-12 col-lg-12 col-xs-12 col-sm-12">
									<?php $i=400;
									if($result5->code==SUCCESS_CODE){
									foreach ($result5->result as $row) { ?>
										<div class="col-xs-12 col-md-12" style="padding-bottom: 15px;">
												<img src="<?php echo ASSIMG.$row->image;?>" style="width:100%;height:15em">
													<br><br>
												<button class="btn btn-warning pull-right btn1" id="<?php echo $row->id;?>">Delete Image</button>
												<br>
												<br>
										</div>
									<?php $i++;}}else{ ?>
									<div class="col-xs-12 col-md-12" style="padding-bottom: 15px;">						
												<p class="alert alert-danger">You haven't submitted Social Media Adgroup Assignment</p>
										</div>
									<?php } ?>
								</div>			  
							</div>
							<div class="col-md-4 col-xs-12 col-sm-4 col-lg-4" style="padding-bottom:1em">
									<h3 class="text-center">Adcopy</h3>
								<div class="col-md-12 col-lg-12 col-xs-12 col-sm-12">
									<?php $i=500;
									if($result6->code==SUCCESS_CODE){
									foreach ($result6->result as $row) { ?>
										<div class="col-md-12 col-lg-12 col-xs-12 col-sm-12" style="padding-bottom:15px">
												<img src="<?php echo ASSIMG.$row->image;?>" style="width:100%;height:15em">
													<br><br>
												<button class="btn btn-warning pull-right btn1" id="<?php echo $row->id;?>">Delete Image</button>
												<br>
												<br>
										</div>
									<?php $i++;}}else{ ?>
									<div class="col-xs-12 col-md-12" style="padding-bottom: 15px;">						
												<p class="alert alert-danger">You haven't submitted Social Media Adcopy Assignment</p>
										</div>
									<?php } ?>
							</div>
						</div>
						</div>  
				  </div> 
			</div>
				<div class="modal-footer">
					  <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
				 </div>
			</div>
		  </div>
	</div>
  </div>
</div>
<div class="container">
	<div class="col-md-12 col-xs-12 col-lg-12 col-sm-12 table-responsive">
	
		<?php if($result->code==SUCCESS_CODE){
		$i=1;
		foreach($result->result as $row){		?>
		<h3><u>Assignment Title: <?php echo $row->name; ?></u></h3>
		<table class="table table-hover table-bordered ">
		  <thead>
			<tr>
			  <th>Topic</th>
			  <th>Campaign</th>
			  <th>Ad Group</th>
			  <th>Ads copy</th>
			</tr>
		  </thead>
		  <tbody>
			<?php foreach($row->result as $rs){ ?>
			<tr>
				<td rowspan="<?php echo count($rs->result)+1; ?>" class="table-heading"><?php echo $rs->name; ?></td>
			</tr>
			<?php foreach($rs->result as $ass){ ?>
			<tr>
				<td><?php echo $ass->campaign; ?></td>
				<td><?php echo $ass->adgroup; ?></td>
				<td><?php echo $ass->adcopy; ?></td>
			</tr>
			<?php } } ?>
			<tr>
				<td>
				</td>
				<td>
					<span class="">
						<form class="forms">
						<input type="hidden" name="nameImg" value="campaign" />
						<input type="hidden" name="assignmentModule" value="<?php echo $row->id; ?>" />
							Upload Assignments... <input class="form-control" type="file" multiple="multiple" id="campaign" name="campaign[]" /><br/>
							<input type="submit" class="btn btn-primary" name="submit" />
						</form>
					</span>
					<img id='img-upload'/>
				</td>
				<td class="">
					<span class="">
						<form class="forms">
							<input type="hidden" name="nameImg" value="adgroup" />
							<input type="hidden" name="assignmentModule" value="<?php echo $row->id; ?>" />Upload Assignments... <input type="file" multiple="multiple" class="form-control" id="adgroup" name="adgroup[]" /><br/>
							<input type="submit" class="btn btn-primary" name="submit" />
							<span class="adgroup_message<?php echo $i; ?>"></span>
						</form>
					</span>				
					<img id='img-upload'/>
			  </td>
			  <td class="">
					<span class="">
						<form class="forms" method="post" enctype='multipart/form-data' >
							<input type="hidden" name="nameImg" value="adcopy" />
							<input type="hidden" name="assignmentModule" value="<?php echo $row->id; ?>" />
							Upload Assignments... <input type="file" multiple="multiple" class="form-control" id="adcopy" name="adcopy[]" /><br/>
							<input type="submit" class="btn btn-primary" name="submit" />
						</form>
					</span>
					<img id='img-upload'/>
			  </td>
			</tr>
		  </tbody>
		</table><?php	$i++; } 
			}  ?><br/>
		<br/>
		<br/>
	</div>
</div>

<?php $this->load->view('footer1');?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.0/jquery-confirm.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.0/jquery-confirm.min.js"></script>
<script>
$(document).ready(function(){
    $(".btn1").click(function(){
		var id = $(this).attr('id');
		alert(id);
		// var strArray = id.match(/(\d+)/g);
		// var i = 0;
		// var id1 = strArray[i];
      // $("#spanid"+id1).html("<form class=forms><input type=hidden name=nameImg value=campaign/><input type=hidden name=assignmentModule value=<?php echo $row->id; ?> />Upload Assignments... <input class=form-control type=file multiple=multiple id=campaign name=campaign[] /><br/><input type=submit class='btn btn-primary btn1' name=submit /></form>");
	  $.confirm({
		title: 'Confirm!',
		content: 'Simple confirm!',
		buttons: {
			confirm: function () {
				$.alert('Confirmed!');
			},
			cancel: function () {
				// $.alert('Canceled!');
			},
		}
	});
    });
});

$("#mybtn").click();
	// $('.form-control').submit(function(e){
	$('.forms').submit(function(e){
		$(this).find(':input[type="submit"]').prop('disabled',true).removeClass('btn-primary').addClass('btn-danger');
		btn =$(this).find(':input[type="submit"]');
		// alert(new FormData(this));
		e.preventDefault(); 
         $.ajax({
			 dataType:'Json',
             url:"<?php echo base_url(); ?>user/do_upload",
             type:"post",
             data:new FormData(this),
             processData:false,
             contentType:false,
             cache:false,
             async:false,
             success:function(s){
				console.log(s);
				// alert(s.description);
				$('#common_footer_popup').modal('show');
				$('.dynamic_title').html('Assignment');	
				switch(s.code)
				{
					case 200:
						$('.dynamic_message').html(s.description).css({'color':'green','font-height':'14px;'});
						btn.removeAttr('disabled').removeClass('btn-danger').addClass('btn-success');
						 setTimeout(function() {window.location=location.href;},4000);
						 // setTimeout(2000);
					break;
					case 204:
					case 301:
					case 422:
					case 575:
						btn.removeAttr('disabled').removeClass('btn-danger').addClass('btn-primary');
						$('.dynamic_message').html(s.description).css({'color':'#c92c33','font-height':'14px;'});
				   break;
				}
			},
			error:function(er){
				console.log(er);
			}
		});
	});  
</script>