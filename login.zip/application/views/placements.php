<?php $this->load->view('header1');?>
<style>
#ul1 {
    list-style-type: square;
    margin: 0;
    padding: 0;
    overflow: hidden;
}
#ul1 li  {
	float: left;
    display: block;   
    text-align: center;
    padding: 16px 16px 16px 10px;
    text-decoration: none;
}
hr { 
    display: block;
    margin-top: 0.5em;
    margin-bottom: 0.5em;
    margin-left: auto;
    margin-right: auto;
    border-style: inset;
    border-width: 0.7px;
}
#jd{
	background: #fff;
    border-radius: 1px solid #e7e7e7;
    margin: 8px 0;
    float: left;
    overflow: hidden;
    padding: 15px 31px 6px 32px;
    position: relative;
    box-shadow: 0 1px 4px rgba(0,0,0,0.04);
}
#jd h4{color: #2c84cc;cursor: pointer;padding:5px;font-size: 1.5em;}
#jd h5{font-weight:bold;padding-left:7px;font-size: 1.1em;}
#jd #skill{padding:10px}
#jd #jdesc{padding:10px;}
#jd #jdesc1{padding-left:8px;}
</style>
		<div class="container">
			<h2 class="text-center">Placement Updates</h2>
		</div>               
		<div class="container">	
			<?php
			if($notifications->code==SUCCESS_CODE){
			foreach ($notifications->result as $row) { ?>    
			<div class="col-md-12">
				<div class="col-md-11 col-sm-10 col-xs-12" id="jd">
				<h4><?php echo $row->profile;?> <span class="pull-right" style="color:#737070! important;font-size:0.7em">Posted  <?php
				// echo date('jS F Y',strtotime($row->added_on));
				echo time_elapsed_string($row->added_on);?>
				</span></h4>
				<h5><?php echo $row->company;?> </h5>
				<ul id="ul1">
					<li class="fa fa-briefcase"> &nbsp;<?php echo $row->experience;?></li>
					<li class="	fa fa-map-marker"> &nbsp;<?php echo $row->location;?></li>
				</ul>
				<p id="jdesc">
					<span><?php echo $row->job_description;?></span><br><br>
					
				
					<span style=";font-weight:bold">Number of Positions: </span><?php echo $row->positions?><br>					
				
					<span style="font-size: 1em;font-weight:bold">Salary: </span><?php echo $row->salary?>
				</p>
				<hr>
				<p id="skill">
					<span style="font-weight:bold">Required Skills : </span><span style=""><?php echo $row->skills;?></span>
					<span class="pull-right"><button type="button" class="btn btn-info">To Apply WhatsApp On <i class="glyphicon glyphicon-earphone"></i> 9325452845</button></span>
				</p>
				</div>
				
			</div>
			<?php } }else{ ?>
			<div class="row">
				<div class="col-md-1 col-xs-12 hidden-xs"></div>
				<div class="col-md-10 col-xs-12 alert alert-danger" id="jd">
				Placement notification not found.
				</div>
				
				<div class="col-md-1 col-xs-12 hidden-xs"></div>
			</div>
			<?php }?>
		</div>
<?php $this->load->view('footer1');?>