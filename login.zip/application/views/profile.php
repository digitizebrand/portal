<?php $this->load->view('header1');?>
    <style>
	.col-md-12{background:white;}
	.vd_bg-yellow {
    background-color: #f89c2c !important;
}.btn-xs {
    font-size: 11px;
    padding: 4px 8px;
}
.vd_btn {
    background-color: #DDDDDD;
    color: #FFFFFF;
}
.btn {
    padding: 6px 15px;
}
.btn-xs, .btn-group-xs>.btn {
    padding: 1px 5px;
    font-size: 12px;
    line-height: 1.5;
    border-radius: 3px;
}
.btn {
    display: inline-block;
    padding: 6px 12px;
    margin-bottom: 0;
    font-size: 14px;
    font-weight: 400;
    line-height: 1.42857143;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    background-image: none;
    border: 1px solid transparent;
    border-radius: 4px;
}.pd-20 {
    padding: 20px !important;
}
label {
    display: inline-block;
    max-width: 100%;
    margin-bottom: 5px;
    font-weight: 700;}
	
}
.tab-content #profile-tab .pd-20 h3{
width:2em;
}
.alert-success1 {
    color: #3c763d;
}
.alert-danger1 {
    color: #cb2a2a;
}
.alert1{
	padding: 0px; 
    margin-bottom: 0px;
    border: none;
    border-radius: 0px;
}
   </style>
	<div class="container">
		<div class="mainbody container-fluid">
			<div class="row">
				<div style="padding-top:50px;"> </div>
					<div class="col-lg-4 col-md-4 col-xs-12">
						<div class="panel panel-default">
							<div class="panel-body">
								<h1 class="panel-title pull-left" style="font-size:30px;"> <span class="glyphicon glyphicon-user"></span> &nbsp;My Profile </h1>
							</div>
						</div>
					</div>
				<div class="col-lg-7 col-md-7 col-sm-12 col-xs-12">
					<div class="panel panel-default">
						<div class="panel-body">
							<h1 class="panel-title" style="font-size:30px;"><i class="fa fa-cogs" aria-hidden="true"></i> &nbsp;My Profile Settings<span class="fa fa-edit pull-right"></span></h1>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
		<div class="container">
		<div class="mainbody container-fluid">
			<div class="row">
				<div style="padding-top:0px;"> </div>
					<div class="col-lg-4 col-md-4 col-xs-12">
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="background:#fff;border-radius: 4px;border-top: 1px solid #ddd;margin-bottom: 20px;">
						<?php
						if($profile->code==SUCCESS_CODE){
						foreach ($profile->result as $row) { ?>
							<div style="height:0.6em;">&nbsp;</div>
							<table class="table table-hover">
									<thead>
										<tr>
										  <th scope="col">Name</th>
										  <th scope="col"><?php echo $row->name;?></th>
										</tr>
									</thead>
								  <tbody>
									<tr>
									  <th scope="row">Email</th>
									  <td><?php echo $row->email;?></td>
									</tr>
									<tr>
									  <th scope="row">Number</th>
									  <td><?php echo $row->mobile;?></td>
									</tr>
									<tr>
									  <th scope="row">Branch </th>
									  <td><?php echo $row->branch_name;?></td>
									</tr>
									<tr>
									  <th scope="row">Batch Time</th>
									  <td><?php echo $row->batch_time;?></td>
									</tr>
									<tr>
									  <th scope="row">Trainer</th>
									  <td><?php echo $row->trainer_name;?></td>
									</tr>
									<tr>
									  <th scope="row">Batch Start Date</th>
									  <td><?php echo date('jS F Y',strtotime($row->batch_start_date));?></td>
									</tr>
									<thead>
										<tr>
										  <td scope="row"></td>
										  <td><button type="button" class="btn btn-primary" id="mypass"><i class="fa fa fa-edit" aria-hidden="true"></i> Change Password</button></td>
										</tr>
									</thead>
								  </tbody>
								</table>
						<?php } } ?>
						</div>
						<div class="panel col-lg-12 col-md-12 col-sm-12 col-xs-12" style="display:none;background:#fff;border-radius: 4px;border-top: 1px solid #ddd;margin-bottom: 20px;" id="showpass">
								<div class="panel-default" >
							<div class="panel-body">
								<h3 class="panel-title pull-left">Change Password</h3>
								<?php #echo print_r($result12);?>
								<br><br>
									<div class="form-group">
										<label for="Password">Current Password
											<span style="color:red"><sup>&nbsp;*</sup></span>
										</label>
										<span id="span_old_pass" class="pull-right"></span>
										 <input class="form-control" id="old_password" name="old_password" type="password" autofocus value="">
										 
										 <label for="password">New Password
											<span style="color:red"><sup>&nbsp;*</sup></span>
										</label>
										<span id="span_new_pass" class="pull-right"></span>
										 <input class="form-control" id="new_password" name="new_password" type="password" autofocus>
										 <label for="password">Confirm Password
											<span style="color:red"><sup>&nbsp;*</sup></span>
										</label>
										<span id="span_confirm_pass" class="pull-right"></span>
										 <input class="form-control" id="confirm_password" name="confirm_password" type="password" autofocus>
										 <br>
										 <span id="pass_status" class=""></span>
											<br><br>
										 <button type="button" class="btn btn-success" id="changemypass">Change Password</button>
										
										 <button type="button" class="btn btn-danger" id="cancelpass">Cancel</button>
										 <br>											
									</div>
									
							</div>
						</div>
						</div>
					</div>
					<div class="col-lg-7 col-md-7 col-sm-12 col-xs-12">
						<?php
						if($profile->code==SUCCESS_CODE){
						foreach ($profile->result as $row) { ?>
						<div class="panel panel-default">
							<div class="panel-body">
								<h3 class="panel-title pull-left">Your Name</h3>
								<br><br>
									<div class="form-group">
										<label for="First_name">Full name<span style="color:red"><sup>&nbsp;*</sup></span></label><span id="span_name" class="error pull-right"></span>
										 <input class="form-control" id="username1" name="user_name" type="text" autofocus value="<?php echo $row->name;?>">
									</div>
							</div>
						</div>
						<div class="panel panel-default">
							<div class="panel-body">
								<h3 class="panel-title pull-left">Your Email</h3>
								<br><br>
									<div class="form-group">
										<label for="Email">Email
											<span style="color:red"><sup>&nbsp;*</sup></span>
										</label>
										<span id="span_email" class="error pull-right"></span>
										 <input class="form-control" id="email" name="user_email" type="email" autofocus value="<?php echo $row->email;?>">
									</div>
								  
							</div>
						</div>
						<!--div class="panel panel-default">
							<div class="panel-body">
								<h3 class="panel-title pull-left">Your photo</h3>
								<br><br>
								<div align="center">
									<div class="col-lg-12 col-md-12">
										<img class="img-thumbnail img-responsive" src="https://lut.im/7JCpw12uUT/mY0Mb78SvSIcjvkf.png" width="300px" height="300px">
									</div>
									<div class="col-lg-12 col-md-12">
										<button class="btn btn-primary"><i class="fa fa-upload" aria-hidden="true"></i> Upload a new profile photo!</button>
									</div>
								</div>
							</div>
						</div-->
						<div class="panel panel-default">
							<div class="panel-body">
								<h3 class="panel-title pull-left">Contact Number</h3>
								<br><br>
									<div class="form-group">
										<label for="First_name">Number
											<span style="color:red"><sup>&nbsp;*</sup></span>
										</label>
										<span id="span_mobile" class="error pull-right"></span>
										 <input class="form-control" id="mobile" name="user_mobile" type="text" pattern="[789][0-9]{9}" value="<?php echo $row->mobile;?>">
									</div>
								  
							</div>
						</div>
						<div class="panel panel-default">
							<div class="panel-body">
								<h3 class="panel-title pull-left">Your Branch<span style="color:red"><sup>&nbsp;*</sup></span></h3>
								<br><br>
									<div class="form-group">
									<span id="span_branch" class="error pull-right"></span>
											<select name="branch" class="form-control"  id="branch" >								
													<option value="">Select Branch (Select One)</option>
												<?php if($branches->code==SUCCESS_CODE){
													foreach($branches->result as $branch){
													?>
														<option <?php echo ($row->branch == $branch->id) ? 'selected' : ''; ?> value="<?php echo $branch->id;?>"><?php echo ucwords($branch->name)?></option>
													
													<?php
													}
												} ?>
											</select>
									</div>                       
							</div>
						</div>
						<div class="panel panel-default">
							<div class="panel-body">
								<h3 class="panel-title pull-left">Your Batch Time<span style="color:red"><sup>&nbsp;*</sup></span></h3>
								<br><br>
									<div class="form-group">  
										<span id="span_batch" class="error pull-right"></span>
											<select name="batch" class="form-control" id="batch" type="select" >
												<option value="">Select Batch (Select One)</option>
												<?php if($batches->code==SUCCESS_CODE){
												foreach($batches->result as $batche){
												?>
													<option <?php echo ($row->batch == $batche->id) ? 'selected' : '' ?> value="<?php echo $batche->id;?>"><?php echo $batche->name;?></option>
												<?php
												}
											} ?>	
											</select>
									</div>
							</div>
						</div>
						<div class="panel panel-default">
							<div class="panel-body">
								<h3 class="panel-title pull-left">Profile settings</h3>
								<br><br>
								<p id="success">	</p>
								<br>
								<button type="button" class="btn btn-primary" id="mybtn"><i class="fa fa-fw fa-check" aria-hidden="true"></i> Update Profile</button>
								<a href="<?php echo current_url();?>" class="btn btn-danger" id="mybtn1"><i class="fa fa-fw fa-times" aria-hidden="true"></i> Cancel</a>
								
							</div>
						</div>
						<?php } }?>
						
				</div>
			</div>
		</div>
	</div>		
<!-- tabs-widget -->              
            <!-- row -->
<?php include_once('footer1.php');?>

<script>
/*To check old password*/
$(document).ready(function(){
	$("#mypass").click(function(){
		$("#showpass").slideDown("slow");
	 });
	 $("#cancelpass").click(function(){
		$("#showpass").slideUp("slow")
	 });
	 $("#old_password").keyup(function(){
		//$("#old_password").css("background-color", "red");
		flag = true;
		let old_password = $("#old_password").val();
		// alert(old_pass);
		if(old_password==''){flag=false;$('#span_old_pass').html('Enter Old Password');$("#old_password").css('border', "1px solid red")}
		// alert(domain);
		if(flag==true){
			$.ajax({
			  dataType:'json',
			  type:'post',
			  data:{'old_password':old_password},
				 url:"<?php echo USER_PATH;?>check_old_password",
				success:function(u){
				//alert('test');
				console.log(u);
				if(u.code=='200'){
					$("#old_password").css("border", "1px solid green");
					$('#span_old_pass').html(u.description).addClass('alert1 alert-success1').removeClass('alert-danger1');
					
					}
						if(u.code=='204' || u.code=='301' || u.code=='422'){$('#span_old_pass').html(u.description).addClass('alert1 alert-danger1');$("#old_password").css("border", "1px solid red");}
					 },
			  error:function(er){
				console.log(er);
			  }
			});
		}
			
		});
});

</script>
<script>
/*to change password*/
$(document).ready(function() {
	$('#confirm_password').keyup(function(event){
		flag = true;
        data = $('#new_password').val();
		data2 = $('#confirm_password').val();
		if(data==''){flag=false;$('#span_new_pass').addClass("alert1 alert-danger1").html('Enter New Password');}
        var len = data.length;
		if(flag==true){
        if(len < 1) {
			$("#span_new_pass, #span_confirm_pass").html("Password Cannot Be Blank");
            // Prevent form submission
            // event.preventDefault();
        }
        if($('#new_password').val() != $('#confirm_password').val()) {
			$('#span_confirm_pass').addClass("alert1 alert-danger1").html('Enter Same Password');
            $("#new_password").css("border","1px solid red");
			 $("#confirm_password").css("border","1px solid red");
            // Prevent form submission
            event.preventDefault();
        }else{
			$('#span_new_pass').removeClass("alert-danger1").html("");
			$('#span_confirm_pass').removeClass("alert-danger1").html("Password Matched");
			// $('#span_new_pass').addClass("alert-success1");
			 $("#new_password").css("border","1px solid green");
			 $("#confirm_password").css("border","1px solid green");
		}
		}
    });
	$("#changemypass").click(function(){
		flag = true;
        let data = $('#new_password').val();
		let data2 = $('#confirm_password').val();
		let old_password = $("#old_password").val();
		if(old_password==''){flag=false;$('#span_old_pass').html('Enter Password');$("#old_password").css('border', "1px solid red");}
		if(data==''){flag=false;$('#span_new_pass').addClass("alert1 alert-danger1").html('Enter New Password');$("#new_password").css('border', "1px solid red");}
		if(data2==''){flag=false;$('#span_confirm_pass').addClass("alert1 alert-danger1").html('Enter same password');$("#confirm_password").css('border', "1px solid red");}
		if(flag==true){
			$("#changemypass").attr('disabled',true);
			$.ajax({
			  dataType:'json',
			  type:'post',
			  data:{'old_password':old_password,'new_password':data,"confirm_password":data2},
				 url:"<?php echo USER_PATH;?>change_password",
				success:function(u){
					
			$("#changemypass").removeAttr('disabled');
				//alert('test');
				console.log(u);
				if(u.code=='200'){$('#pass_status').html(u.description).addClass('alert1 alert-success1');}
						if(u.code=='204' || u.code=='301' || u.code=='422'){$('#pass_status').html(u.description).addClass('alert1 alert-danger1');}
								  setTimeout(function(){
									   window.location.reload();
									}, 3000);
					 },
			  error:function(er){
				console.log(er);
			  }
			});
		}
        });
});
</script>
<script>
/* to update user details */
$(document).ready(function(){
    $("#mybtn").click(function(){
		flag = true;
		let name = $("#username1").val();
		let email = $("#email").val();
		let mobile = $("#mobile").val();
		let branch = $("#branch").val();
		let batch = $("#batch").val();
		let user_id = <?php echo $this->user_id; ?>;
		// alert(name + " " + email+ " " + mobile+" " + branch+" " + batch+" "+user_id);
		if(name==''){flag=false;$('#span_name').html('Name cannot be empty');$("#username1").css('border', "1px solid red")}
		if(email==''){flag=false;$('#span_email').html(' Email cannot be empty');$("#email").css('border', "1px solid red")}
		if(mobile==''){
			flag=false;$('#span_mobile').html(' Mobile Number cannot be empty');$("#mobile").css('border', "1px solid red");
			}else{
			var filter = /^\d*(?:\.\d{1,2})?$/;
          if (filter.test(mobile)) {
            if(mobile.length==10){
                  // alert("valid");
              $('#span_mobile').html('');
             } else {
                $('#span_mobile').html(' Enter 10 digit mobile number');$("#mobile").css('border', "1px solid red");
                return false;
              }
            }
            else {
              $('#span_mobile').html(' Invalid Number');$("#mobile").css('border', "1px solid red");
              return false;
           }
			}
		if(branch==''){flag=false;$('#span_branch').html(' Select Branch');$("#branch").css('border', "1px solid red")}
		if(batch==''){flag=false;$('#span_batch').html(' Select Batch');$("#batch").css('border', "1px solid red")}
		// alert(domain);
		if(flag==true){
			$("#username1, #email, #mobile, #branch, #batch").css('border', "1px solid green");
			$.ajax({
			  dataType:'json',
			  type:'post',
			  data:{'name':name,'email':email,'mobile':mobile,'branch':branch,'batch':batch,'user_id':user_id},
				 url:"<?php echo USER_PATH;?>update_profile",
				success:function(u){
				//alert('test');
				console.log(u);
				if(u.code=='200'){$('#success').html(u.description).addClass('alert alert-success');}
						if(u.code=='204' || u.code=='301' || u.code=='422'){$('#success').html(u.description).addClass('alert alert-danger');}
						 $("#mybtn").attr('disabled',true);
						  setTimeout(function(){
							   window.location.reload();
							}, 2000);
					 },
			  error:function(er){
				console.log(er);
			  }
			});
		}
        });
    })
</script>