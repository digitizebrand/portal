<?php
$user_id=$this->session->userdata('user_id');
if(!$user_id){
	$this->load->view('register');
}
$this->load->view('header1');?>
<style>
.psize{
font-size: 20px;
}
.psize1{
font-size: 20px;
}
.psize1 li{margin-left: 2em;}
.psize a:hover{
    text-decoration:underline;
}
.form-control{
    height:2.5em! important;
    font-size: 17px! important;
}
#btn1,#btn2{background-color: #3bc0c3;border: 1px solid #3bc0c3;}
	.vd_bg-yellow {
    background-color: #f89c2c !important;
}.btn-xs {
    font-size: 11px;
    padding: 4px 8px;
}
.vd_btn {
    background-color: #DDDDDD;
    color: #FFFFFF;
}
.btn {
    padding: 6px 15px;
}
.btn-xs, .btn-group-xs>.btn {
    padding: 1px 5px;
    font-size: 12px;
    line-height: 1.5;
    border-radius: 3px;
}
.btn {
    display: inline-block;
    padding: 6px 12px;
    margin-bottom: 0;
    font-size: 14px;
    font-weight: 400;
    line-height: 1.42857143;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    background-image: none;
    border: 1px solid transparent;
    border-radius: 4px;
}.pd-20 {
    padding: 20px !important;
}
label {
    display: inline-block;
    max-width: 100%;
    margin-bottom: 5px;
    font-weight: 700;}
	#name, #email, #mobile, #batch, #branch{
	    width: 20em;
		padding-left:2em;
		}
}
.tab-content #profile-tab .pd-20 h3{
width:2em;
}
#loading {
	display: none;
}

#Heading {
	-moz-border-radius:10px 10px 0 0;
	-moz-box-shadow:0 0 1px #FD0000 inset;
	background:-moz-linear-gradient(center top , #DB0000, #9B0000) repeat scroll 0 0 transparent;
	border:1px solid #8D0000;
	color:white;    margin-top: 6px;
    margin-left: -1px;
	font-size:22px;
	padding:16px;
	text-shadow:0 1px 1px black;
	z-index:2;
	background: -webkit-gradient(linear, left top, left bottom, from(#db0000), to(#9b0000));
    background: -moz-linear-gradient(top center, #db0000, #9b0000);
    
    -webkit-border-radius: 10px 10px 0 0;
    -webkit-background-clip: padding-box;
    -webkit-box-shadow: inset 0 0 1px #fd0000;
    -moz-border-radius: 10px 10px 0 0;
    -moz-background-clip: padding-box;
    -moz-box-shadow: inset 0 0 1px #fd0000;
	-webkit-border-radius: 15px;
	top:6px;
	width:220px;
   	color:#ccc;
    position: relative;
	text-transform:uppercase;text-shadow: 1px 1px 1px #000;
}

#form {
	width:520px;
    background-color: #463d00;
    padding: 40px 50px 30px;
    margin: 0px 0;
    position: relative;
    border-radius: 15px;
    -moz-border-radius: 15px;
    -webkit-border-radius: 15px;
	-moz-border-radius:15px 15px 15px 15px;
}

#Search {
	background:url("<?php echo ASSETS;?>img/Text.png") no-repeat scroll 0 0 transparent;
	border:medium none;
	color:#888888;
	float:left;
	font-family:Arial,Helvetica,Sans-serif;
	font-size:15px;
	height:36px;
	margin-right:12px;
	outline:medium none;
	padding:0 0 0 35px;
	text-shadow:1px 1px 0 white;
	width:425px;
}

#Submit {
	background:url("<?php echo ASSETS;?>img/Search.png") no-repeat scroll 0 0 transparent;
	border:medium none;
	cursor:pointer;
	height:36px;
	overflow:hidden;
	text-indent:-999px;
	text-transform:uppercase;
	width:83px;
}

h4 {
	border:2px solid #EEEEEE;
	font:14px/1.3 Verdana,"Lucida Grande",Arial,Helvetica,Sans-Serif;
	margin:0px;
	padding:5px;
	min-width:120px;
	text-align:left
}

h4.taken span {
	background:none repeat scroll 0 0 #F08F78;
}
h4.taken:hover{
	background:none repeat scroll 0 0 #FFC5B7;
}

h4 a{font-family:"crete-rounded-web-1","crete-rounded-web-2",sans-serif; color:#333333}
 
h4 span {
	font-family:Verdana;
	font-size:12px;
	font-style:normal;
	margin-right:4px;
	padding:3px 5px;
}

h4.available:hover {
	background:none repeat scroll 0 0 #DDF2BC;
}
 h4.available span { background: #bce67b; }
 .embed-responsive  #ifr.footer{display:none;}
   </style>

<div class="container">
	<h2 class="text-center">Domain Registration Process</h2>
</div>
	<div class="container">
		<div class="row">
			<div class="col-md-5 col-sm-6 col-lg-5 col-xs-12"> 
				<h3>Step 1: Domain Name Availablility </h3>
			</div>
		</div>
		<div class="row">
			<div class="col-md-1 col-sm-6 col-xs-12"> 
			</div>
			<div class="col-md-10 col-sm-6 col-xs-12">
				<p class="psize">
					Enter your domain name in 'DOMAIN CHECKER' field and click on search. If it is <span class="alert alert-success" style="padding: 5px;">available</span>, you can proceed to next step. If it is <span class="alert alert-danger" style="padding: 5px;">taken</span> search for the domain name which is available. It is mandatory to check domain name availablility to avoid any unwanted delay in your domain name registration process.
					<ol class="psize1" style="padding-left:0px"><strong>Follow the steps below to help you pick the perfect domain name :</strong> 
						<li>Make it easy to type</li>
						<li>Keep it short</li>
						<li>Use keywords</li>
						<li>Target your area</li>
						<li>Avoid numbers and hyphens</li>
						<li>Research it</li>
						<li>Use an appropriate domain name extension</li>
					</ol>
				</p>
			</div>
		</div>
		<div class="row">
			<div class="col-md-6 col-sm-6 col-lg-12 col-xs-12 col-md-offset-1 col-lg-offset-1 col-sm-offset-1">
				<div id="Heading">Domain Checker</div>
					<form method="post" action="" id="form">
						<input type="text" autocomplete="off" id="Search" name="domain"> 
						<input type="submit" id="Submit" value="Submit">
					</form>
					<div id="loading">Please wait...<img src="<?php echo ASSETS;?>img/load.gif"></img></div>
					 <div id="results" style="width: 420px;height: 340px;display: none;" align="left">
					 </div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-3 col-sm-6 col-xs-12"> 
				<h3>Step 2: Signup Process</h3>
			</div>
		</div>
		<div class="row">
			<div class="col-md-1 col-sm-6 col-xs-12"> 
			</div>
			<div class="col-md-10 col-sm-6 col-xs-12">
				<p class="psize">
					To register domain you need to complete signup process. You can either register in below page or <a href="http://digitize-brand.market.wwwengine.net/" target="_blank" style="color:blue">Click here</a> to signup. To signup for domain registration kindly watch complete video to avoid any unwanted circumstances.
					<br><br>
					<iframe width="100%" height="420" src="https://www.youtube.com/embed/0-BbyL0VaYA" allowfullscreen="allowfullscreen" frameborder="0">
				  </iframe>
				</p>
				  <br>
					<ol class="psize">Note : 
						<li>Call-in-PIN : 1234</li>
						<li>ALLOW LOGIN FROM IPV4 ADDRESSES KEEP IT BLANK</li>
						<li>After registration it will take 24 to 48 hours for c-panel access</li>
					</ol>
				  <div id="Iframe-Master-CC-and-Rs document-viewer" class="set-margin set-padding set-border set-box-shadow center-block-horiz" style="">
					<div style="margin-top:1em" class="hidden-xs">&nbsp;</div>  
					  <div class="embed-responsive embed-responsive-4by3" >
						<iframe id="ifr" class="col-lg-12 col-xs-12 col-md-12" src="http://digitize-brand.market.wwwengine.net/"> 
						  <p style="font-size: 110%;"><em><strong>ERROR: </strong>  
							An &#105;frame should be displayed here but your browser version does not support &#105;frames. </em>Please update your browser to its most recent version and try again.
						</p>
						</iframe>
						
					  </div>
					</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-4 col-sm-6 col-xs-12"> 
				<h3>Step 3: Submit Domain Name</h3>
			</div>
		</div>
	
		<div class="col-md-1 col-sm-4 hidden-xs"></div>
		<div class="col-md-5 col-sm-4 col-xs-12"><br><br>
				
				<p class="psize">
					Please submit your domain name that will be best suited for your company. For example- digitaltrainee.com.
					You will get cPanel access within 24 to 48 hours after submitting domain name.
					For technical queries email us on support@digitizebrand.com.
					
				</p>
				<?php if($domain1->code==SUCCESS_CODE){ 				
					?>
				<p class="psize alert alert-success">
				You have already submitted <b><?php echo $domain1->row->name; ?> </b>domain name <?php echo time_elapsed_string($domain1->row->added_on); ?>.<br> You will get cPanel access within 24 to 48 hours after submitting domain name. If you wish to change your domain name, kindly email us on support@digitizebrand.com or call us on 9325466603.
				</p>
				<?php } ?>
		</div>
		<div class="col-md-5 col-sm-5 col-xs-12"><br><br>
			<?php
			if($domain1->code==SUCCESS_CODE){
				$dom = explode(".",$domain1->row->name);	
			?>
				<div class="form">
					  <div class="form-group">
						<input type="text" class="form-control" style="background-color:white" id="domain_name" placeholder="<?php echo $dom[0]; ?>" readonly>
					  </div>
					  <div class="form-group">
						<select class="form-control" id="sel2">
							<option selected>
								<?php if(count($dom)>2){
								$dom = $dom[1].".".$dom[2];echo ".".$dom;}else{echo $dom[1];} ?></option>
							
						</select>
					  </div>
					  <div class="form-group">
						<button type="button" class="btn btn-primary form-control" id="btn2">Submit</button>
					  </div>
					  <div id="danger">
					  </div>
				</div>
					 <?php   }else{?>
					 <div class="form">
					  <div class="form-group">
						<input type="text" class="form-control" id="domain_name" placeholder="Please Enter Domain name">
					  </div>
					  <div class="form-group">
						<select class="form-control" id="sel1">
							<option value="">Select Domain Type</option>
							<option>.com</option>
							<option>.in</option>							
							<option>.co.in</option>
							<option>.net</option>
							<option>.net.in</option>
						</select>
					  </div>
					  <div class="form-group">
						<button type="button" class="btn btn-primary form-control" id="btn1">Submit</button>
					  </div>
				</div>
				<?php }?>
			<br><br>
			<div id="success">
			</div>
			<br><br><br><br><br><br>
		</div>	
		</div>
</div>
<?php $this->load->view('footer1');?>
<script language="javascript">
$(document).ready(function() {
	var loading;
	var results;
	form = document.getElementById('form');
	loading = document.getElementById('loading');
	results = document.getElementById('results');
	$('#Submit').click( function() {
		// alert($('#Search').val());
		if($('#Search').val() == "")
		{alert('please enter your domain');return false;}
		results.style.display = 'none';
		$('#results').html('');
		loading.style.display = 'inline';
		$.post("<?php echo DIGITAL_TRAINEE; ?>process.php?domain=" + escape($('#Search').val()),{
		}, function(response){
			results.style.display = 'block';
			$('#results').html(unescape(response));	
			loading.style.display = 'none';
		});
		return false;
	});
	
});
</script>
<script>
	$("#btn2").attr('disabled',true);
$(document).ready(function(){
    $("#btn2").click(function(){
	$("#danger").addClass("alert alert-danger");
	$("#danger").html("You have already submitted domain name. To update domain name kindly contact us on 9325466603 or email us on support@digitizebrand.com");

        // alert("sfsdf");
    });
});
 // $("#btn2").click(function(){
	// alert("btn2");
		// $("#dang").addClass("alert");
		
	// }
$(document).ready(function(){
    $("#btn1").click(function(){
		$("#btn1").attr('disabled',true);
		var domain_name = $("#domain_name").val();
		var domain_type=$("#sel1").val();
		if(domain_name==''){
		$('#domain_name').css('border','1px solid red');
		return false;		
		}
		if(domain_type==''){
		$('#sel1').css('border','1px solid red');
		return false;	
		}
		var domain = domain_name+domain_type;
		// alert(domain);
		$.ajax({
          dataType:'json',
          type:'post',
          data:{'domain':domain},
		     url:"<?php echo USER_PATH;?>domain",
			success:function(u){
			//alert('test');
            console.log(u);
            if(u.code=='200'){$('#success').html('You requested domain name has been submitted successfully. You will get Cpanel access within next 24 to 48 hours.For technical queries email us on support@digitizebrand.com.').addClass('alert alert-success');}
                    if(u.code=='204' || u.code=='301' || u.code=='422'){$('#success').html(u.description).addClass('alert alert-danger');}
							 $("#btn1").attr('disabled',true);

                 },
          error:function(er){
            console.log(er);
          }
        });
        });
    });
</script>