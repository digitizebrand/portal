<?php
class User_model extends CI_model{
	public function register_user($user){
		$this->db->insert('user', $user);
	}
public function login_user($email,$pass){
  $this->db->select('*');
  $this->db->from('user');
  $this->db->where('email',$email);
  $this->db->where('password',$pass);

  if($query=$this->db->get())
  {
      return $query->row_array();
  }
  else{
    return false;
  }
}
	public function email_check($email){
		$this->db->select('*');
		$this->db->from('user');
		$this->db->where('email',$email);
		$query=$this->db->get();
		if($query->num_rows()>0){
			return false;
		}else{
			return true;
		}
	}
	public function profile($id){
	$response = array();
	// $res = "";
	  $this->db->select('u.*,b.name as branch_name,c.id as batch,c.name as batch_time,t.name as trainer_name');
	  $this->db->from('user u');
	  $this->db->where('u.id',$id);
	  $this->db->join('dt_branches_tbl b','b.id=u.branch');
	  $this->db->join('batches_tbl c','c.id=u.batch');	
	  $this->db->join('dt_trainer_tbl t','t.id=u.trainer');	
	  $query=$this->db->get();
		$count=$query->num_rows();
		if ($count>0) {
                $response[CODE] = SUCCESS_CODE;
                $response[MESSAGE] = 'Success';
                $response[DESCRIPTION] = $count.'records found';
				$response['result']=$query->result(); 
				return json_encode($response);exit;
            } else 
            {
                $response[CODE] = FAIL_CODE;
                $response[MESSAGE] = 'Fail';
                $response[DESCRIPTION] = 'No records found';
            }
			return json_encode($response);
	}
	public function domain($id){
	$response = array();
	// $res = "";
	  $this->db->select('name');
	  $this->db->from('domain_tbl');
	  $this->db->where('user_id',$id);
	  $query=$this->db->get();
	 $count=$query->num_rows();
		if ($count>0) {
                $response[CODE] = SUCCESS_CODE;
                $response[MESSAGE] = 'Success';
                $response[DESCRIPTION] = $count.'domain name found';
				$response['row']=$query->result(); 
				return json_encode($response);exit;
            } else 
            {
                $response[CODE] = FAIL_CODE;
                $response[MESSAGE] = 'Fail';
                $response[DESCRIPTION] = 'No records found';
            }
			return json_encode($response);
	}
	public function assignments(){
		$this->db->select('*')->from('dt_assignment_modules_tbl')->where('parent_id',0);
		$query=$this->db->get();
		$count=$query->num_rows();
		$result=array();
		if ($count>0) {
			$response[CODE] = SUCCESS_CODE;
			$response[MESSAGE] = 'success';
			$response[DESCRIPTION] = 'records found';
			$response['result'] = array();
			// print_r($query->result);exit;
			foreach($query->result() as $ass){
				$topics=array('result'=>array());
				foreach($ass as $key=>$value){
					$topics[$key]=$value;
				}
				$this->db->select('*')->from('dt_assignment_modules_tbl')->where('parent_id',$ass->id);
				$query=$this->db->get();
				$count=$query->num_rows();				
				foreach($query->result() as $row){
					foreach($row as $key=>$value){
						$result[$key]=$value;
					}
					$this->db->select('a.*');
					$this->db->from('dt_assignments_tbl a')->where('a.topics',$row->id);
					$query=$this->db->get();
					$count=$query->num_rows();
					$result['result']=$query->result();
					array_push($topics['result'],$result);
				}
				array_push($response['result'],$topics);
			}
		}else{
			$response[CODE] = FAIL_CODE;
			$response[MESSAGE] = 'Fail';
			$response[DESCRIPTION] = 'No records found';
		}
		// print_r($response);exit;
		return json_encode($response);
	}
	public function review($id){
		$response = array();
		$this->db->select('t.name as trainer_name');
		$this->db->from('dt_trainer_tbl t');
		$this->db->where('u.id',$id);
		$this->db->join('user u','u.trainer=t.id');
		$query=$this->db->get();
		$count=$query->num_rows();
		if ($count>0) {
			$response[CODE] = SUCCESS_CODE;
			$response[MESSAGE] = 'Success';
			$response[DESCRIPTION] = $count.'records found';
			$response['result']=$query->row(); 
			return json_encode($response);exit;
		} else 
		{
			$response[CODE] = FAIL_CODE;
			$response[MESSAGE] = 'Fail';
			$response[DESCRIPTION] = 'No records found';
		}
		return json_encode($response);
	}
}