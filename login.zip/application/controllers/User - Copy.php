<?php
defined('BASEPATH') OR exit('No direct script access allowed');
	class User extends CI_Controller {
	public $data = '';
	public function __construct(){
        parent::__construct();
  		$this->load->helper('url');
  	 	$this->load->model('user_model');
        $this->load->library(array('session','form_validation')); 
		$this->user_id=$this->session->userdata('user_id');
		$this->data['user_id']=$this->user_id;
		$this->controller_path=USER_PATH;
		$this->payment_status=$this->crud->commonCheck('id', 'user', array('payment'=>1,'id'=>$this->user_id));
		$params = array('table'=>'dt_branches_tbl','where'=>array('status'=>1));	
		$this->data['branches']=json_decode($this->crud->commonget($params));
		$params = array('table'=>'bd_tbl','where'=>array('status'=>1));
		$this->data['bds']=json_decode($this->crud->commonget($params));
		$params = array('table'=>'batches_tbl','where'=>array('status'=>1));
		$this->data['batches']=json_decode($this->crud->commonget($params));
		$params = array('table'=>'dt_trainer_tbl','where'=>array('status'=>1));
		$this->data['trainer']=json_decode($this->crud->commonget($params));
	}
	public function index()
	{
		($this->user_id=='')?'':redirect(base_url().'user/dashboard/');
		$this->load->view("register",$this->data);	
	}
	public function register_user(){
		$password=$this->input->post('user_password1');
		$name=ucwords($this->input->post('user_name'));
		$email=$this->input->post('user_email');
		$user=array(
			'name'=>$name,
			'email'=>$email,
			'branch'=>$this->input->post('branch'),
			'batch'=>$this->input->post('batch'),
			'bd'=>$this->input->post('bd'),
			'password'=>md5($password),
			'mobile'=>$this->input->post('user_mobile'),
			'trainer'=>$this->input->post('trainer'),
			'purpose'=>$this->input->post('purpose'),
			'batch_start_date'=>date("Y-m-d", strtotime($this->input->post('date'))),
			'status'=>0,
			'added_on'=>DATE,
			'payment'=>0	  
		);
		$email_check=json_decode($this->crud->commonCheck('id','user',array('email'=>$user['email'])));
		if($email_check==0){
			$res=json_decode($this->crud->commonInsert('user',$user,'success'));
			if($res->code==SUCCESS_CODE){
				$email_data= array(
					'name'=>$name,
					'title'=>SITE_TITLE.' Credentials',
					'link_title'=>' Login Here',
					'vlink'=>base_url(),
					'message'=>" Thank you for signing up with us. Below are the credentials of your ".SITE_TITLE." account. Save this for future references.<br/> <br/>
						Username: $email,<br/>
						Password: $password<br/>
						<br/><br/>
					<p style='color:red' align='justify'><sup>*</sup> You will receive an email once your account get activated. It will take 24 to 48 hours for activation. If you do not receive an email within 24 to 48 hours contact your Trainer.</p>"
				);
				$email_array = array(
					'to' =>array($email),
					'cc' => array($email),
					'subject' => "$name, your ".SITE_TITLE." registration process has been completed",
					'data' => array('data' => $email_data),
					'template' =>'templates/credentials',
				);
				$result=(SEND_MAIL==1)?$this->sendmail->sendEmail($email_array):'';
				$result_mail=(SEND_MAIL==1)?$result['code']:1;
			}
			// $this->user_model->register_user($user);
			$this->session->set_flashdata('success_msg1', 'Registered successfully.');
			redirect(base_url());
		}else{
			// echo 'fail';
			$this->session->set_flashdata('error_msg1', $user['email'].' is already exists.');
			$this->load->view("register",$this->data);
		}
	}
	public function login_view(){
		($this->user_id=='')?'':redirect(base_url().'user/dashboard/');
		$this->load->view("login");
	}
function login_user(){
	($this->user_id=='')?'':redirect(base_url().'user/dashboard/');
	$user_login=array(
		'email'=>$this->input->post('user_email'),
		'password'=>md5($this->input->post('user_password'))
    );
    $data=$this->user_model->login_user($user_login['email'],$user_login['password']);
	// print_r $data;
	if($data)
	{
		if($data['status']==0){
			$this->session->set_flashdata('error_msg', 'Oops! your account is not activated yet. Please contact to your trainer.');
			// $this->load->view("register",$this->data);
			redirect(base_url());
		}else{
			$this->session->set_userdata('user_id',$data['id']);
			$this->session->set_userdata('user_email',ucfirst($data['email']));
			$this->session->set_userdata('user_name',$data['name']);
			$this->session->set_userdata('user_mobile',$data['mobile']);
			$this->session->set_userdata('payment',$data['payment']);
			redirect(base_url().'user/dashboard/');
		}
	}else{
        $this->session->set_flashdata('error_msg', 'Oops! incorrect username or password, Please try again.');
        // $this->load->view("register",$this->data);
		redirect(base_url());
	}
}
	function dashboard(){
		($this->user_id!='')?'':redirect(base_url().'user/');
		$this->data['D']=1;
		$function_title='Dashboard';
		$this->data['URL_TITLE'] = ' Student | '.$function_title;
		$this->data['BACK_TITLE'] = ' Dashboard ';
		$this->data['BACK_LINK'] = $this->controller_path;
		$this->data['PAGE_TITLE'] = $function_title;
		$breadcrumb_array = array
		(
			array('title' => 'Dashboard', 'link' => 'javascript:void(0);', 'class' => 'active'),
		);
		$this->data['breadcrumb'] = json_encode($breadcrumb_array);
		$params1 = array('table'=>'syllabus_pdf');
		$this->data['result']=json_decode($this->crud->commonget($params1));
		$params = array('table'=>'study_material_pdf');
		$this->data['study_result']=json_decode($this->crud->commonget($params));
		$this->load->view('user_profile',$this->data);
	}
function syllabus(){
	($this->user_id=='')?redirect(base_url()):'';
	$this->data['S']=1;
	$params = array('table'=>'syllabus_pdf');
	$this->data['result']=json_decode($this->crud->commonget($params));
	$this->load->view('syllabus',$this->data);
}
function view_study_material(){
	($this->user_id=='')?redirect(base_url()):'';
	$this->data['SM']=1;
	$params = array('table'=>'study_material_pdf');
	$this->data['result']=json_decode($this->crud->commonget($params));
	$this->load->view('study-material',$this->data);
}
function videos(){
	($this->user_id=='')?redirect(base_url()):'';
	$this->data['VD']=1;
	$params = array('table'=>'dt_videos_tbl','where'=>array('status'=>1));
	$this->data['result']=json_decode($this->crud->commonget($params));
	$this->load->view('videos',$this->data);
}
	function domain_registration(){
		($this->user_id=='')?redirect(base_url()):'';
		($this->payment_status!=1)?redirect(base_url()):'';
		$this->data['DR']=1;		
		$params = array('table'=>'domain_tbl','where'=>array('user_id'=>$this->user_id));
		$this->data['domain1']=json_decode($this->crud->commonget($params));
		$this->load->view('domain_registration',$this->data);
	}
function domain(){
	($this->user_id=='')?redirect(base_url()):'';
	$domain = $this->input->post('domain');
	$date=DATE;
	if($domain=="")
	{
		echo json_encode(array('code'=>FAIL_CODE));
	}else{
		$domainexists=$this->crud->commonCheck('id', 'domain_tbl', array('user_id'=>$this->user_id));
		if($domainexists==1){
			$response[CODE]=EXISTS_CODE;
			$response[DESCRIPTION]='You have already submitted domain name. To update domain name kindly contact us on 9325466603 or email us on support@digitizebrand.com';
		}else{
		$domain_name=array(
		  'name'=>$domain,
		  'added_on'=>$date,
		  'user_id'=>$this->user_id,
		  'status'=>0,
		);
		$response=json_decode($this->crud->commonInsert('domain_tbl',$domain_name,'success'));
		$params = array('table'=>'user','where'=>array('id'=>$this->user_id));
		$result=json_decode($this->crud->commonget($params));
		// print_r($result);exit;
		$row=$result->row;
		$date = date("l jS \of F Y h:i A");
		$email_data= array(
			'name'=>' Team',
			'title'=>' Domain Registration Request',
			'link_title'=>' Register Domain ',
			'vlink'=>base_url().'superadmin',
			'message'=>" Below are candidate details to register domain - $domain <br/>
				Name:	 $row->name<br/>
				Email:	<i> $row->email</i><br/>
				User id: $this->user_id,<br/>
				on	$date"
		);
		$email_array = array(
			'to' =>array('support@digitizebrand.com'),
			'cc' => array('support@digitizebrand.com'),
			'subject' => SITE_TITLE." - Domain Registration Request - $row->name",
			'data' => array('data' => $email_data),
			'template' =>'templates/domain_registraition',
		);
		// print_r($email_array);exit;
		// $this->load->view('templates/reset_password',$email_array['data']);
		$result_mail=1;
		$result=(SEND_MAIL==1)?$this->sendmail->sendEmail($email_array):'';
		$result_mail=(SEND_MAIL==1)?$result['code']:1;
		// print_r($result);exit;
		}
		echo json_encode($response);
	}
}
function check_domain(){
	// print_r($_REQUEST);exit;
	set_time_limit(0);
	ob_start();
	########### Extensions to be checked
	$extensions = array(
		'.com' 		=> array('whois.crsnic.net','No match for'),
		'.net' 		=> array('whois.crsnic.net','No match for'),
		'.in' => array('whois.inregistry.net', 'NOT FOUND'),
		'.co.in' => array('whois.inregistry.net', 'NOT FOUND'),
		'.net.in' => array('whois.inregistry.net', 'NOT FOUND'),
		);
	if(isset($_GET['domain']))
	{
		$domain = str_replace(array('www.', 'http://'), NULL, $_GET['domain']);
		if(strlen($domain) > 0)
		{
			foreach($extensions as $extension => $who)
			{
				$buffer = NULL;
				$sock = fsockopen($who[0], 43) or die('Error Connecting To Server:' . $server);
				fputs($sock, $domain.$extension . "\r\n");
					while( !feof($sock) )
					{
						$buffer .= fgets($sock,128);
					}
				fclose($sock);
				if(preg_match($who[1], $buffer))
				{
					echo '<h4 class="available"><span>Available</span>' . $domain. '<b>' . $extension .'</b> is Available</h4>';
				}
				else
				{
					echo '<h4 class="taken"><span>Taken</span>' . $domain . '<b>' .$extension .'</b> is Taken</h4>';
				}
				echo '<br />';	
				ob_flush();
				flush();
				sleep(0.3);
			}
		}else{
			echo 'Please enter the domain name';
		}
	}
}
/*===== Freelancing pdf view =====*/
function freelancing(){
	($this->user_id=='')?redirect(base_url()):'';
	$this->data['FL']=1;
	$params = array('table'=>'dt_freelancing_tbl','where'=>array('status'=>1));
	$this->data['result']=json_decode($this->crud->commonget($params));
	$this->load->view('freelancing',$this->data);
}
/*===== Assignements code Start =====*/
	function img_upload($name,$path)
	{
		ini_set('memory_limit', '-1');
		// $name='image';
		// echo $_FILES[$name]["name"];exit;
		if(!empty($_FILES[$name]["name"]))  
		{
			// $path=IMAGES_PATH;
			$config['upload_path'] = $path;  
			$config['allowed_types'] = 'jpg|jpeg|png|gif';  
			$config['max_size']    = '2048';
			$this->load->library('upload', $config);  
			if(!$this->upload->do_upload($name))  
			{
				$error=$this->upload->display_errors();
				$this->session->set_flashdata('failure',$error);	
			}else{  
				 $data = $this->upload->data();  
				 return $data["file_name"];
			}
		}else{
			$this->session->set_flashdata('failure','You are not selected '.$name);
			return false;
		}
	}
function assignments(){
	#if user is not logged in redirect login page
	($this->user_id=='')?redirect(base_url()):'';
	$this->data['AS']=1;
	$this->data['review']=json_decode($this->user_model->review($this->user_id));
	$where2 = array('user_id'=>$this->user_id,'assignment_module'=>1);
	$params = array('table'=>'dt_assignments_review_tbl','where'=>$where2);
	$this->data['result_ga']=json_decode($this->crud->commonget($params));
	$where2['assignment_module']=2;
	$params['where']=$where2;
	$this->data['result_sm']=json_decode($this->crud->commonget($params));
	/*Google Adwords*/
	$where = array('user_id'=>$this->user_id,'type'=>'campaign','assignment_module'=>1);
	$params = array('table'=>'dt_assignments_completed_tbl','where'=>$where);
	$this->data['result1']=json_decode($this->crud->commonget($params));
	$where['type']='adgroup';		
	$params['where']=$where;
	$this->data['result2']=json_decode($this->crud->commonget($params));
	$where['type']='adcopy';$params['where']=$where;
	$this->data['result3']=json_decode($this->crud->commonget($params));
	/*Social Media*/
	$where = array('user_id'=>$this->user_id,'type'=>'campaign','assignment_module'=>2);
	$params = array('table'=>'dt_assignments_completed_tbl','where'=>$where);
	$this->data['result4']=json_decode($this->crud->commonget($params));
	$where['type']='adgroup';		
	$params['where']=$where;
	$this->data['result5']=json_decode($this->crud->commonget($params));
	$where['type']='adcopy';$params['where']=$where;
	$this->data['result6']=json_decode($this->crud->commonget($params));
	$this->data['result']=json_decode($this->user_model->assignments());
		$this->load->view('assignments',$this->data);	
}
function delete_image(){
	$id = $this->input->post('id1');
	$where = array('id'=>$id);
	$params = array('table'=>'dt_assignments_completed_tbl','where'=>$where);
	$result=json_decode($this->crud->commonget($params));
	$img = $result->row->image;
	$image_path="./uploads/assignments/".$img;
	unlink($image_path);
	echo $this->crud->commonDelete('dt_assignments_completed_tbl',$where, ' assignments');
}
/*===== Assignements code End =====*/
function placements(){	
	($this->user_id=='')?redirect(base_url()):'';
	($this->payment_status!=1)?redirect(base_url()):'';
	$this->data['PS']=1;
	$params = array('table'=>'placements_tbl','where'=>array('status'=>1),'order_by_val'=>'DESC','order_by'=>'id');	
	$this->data['notifications']=json_decode($this->crud->commonget($params));
	$this->load->view('placements',$this->data);
}
function resume(){	
	($this->user_id=='')?redirect(base_url()):'';
	$this->data['RE']=1;
	$params = array('table'=>'dt_resume_tbl','where'=>array('status'=>1));
	$this->data['result']=json_decode($this->crud->commonget($params));
	// $this->load->view('fileup/index',$this->data);
	$this->load->view('resume',$this->data);
}
function interview_questions(){	
	($this->user_id=='')?redirect(base_url()):'';
	$this->data['IQ']=1;
	$params = array('table'=>'dt_interview_tbl','where'=>array('status'=>1));
	$this->data['result']=json_decode($this->crud->commonget($params));
	// $this->load->view('fileup/index',$this->data);
	$this->load->view('interview-questions',$this->data);
}

	public function uploadAssignment(){
		error_reporting(E_ALL | E_STRICT);
		include_once APPPATH.'/third_party/php/UploadHandler.php';
		// require('UploadHandler.php');
		$upload_handler = new UploadHandler();
	}
	function profile(){
		($this->user_id=='')?redirect(base_url()):'';
		$this->data['PR']=1;
		$params = array('table'=>'user','where'=>array('id'=>$this->user_id));	
		$this->data['profile']=json_decode($this->user_model->profile($this->user_id));
		$password=$this->input->post('user_password1');
		$name=ucwords($this->input->post('user_name'));
		$email=$this->input->post('user_email');
		$user=array(
			'name'=>$name,
			'email'=>$email,
			'branch'=>$this->input->post('branch'),
			'batch'=>$this->input->post('batch'),
			'password'=>md5($password),
			'mobile'=>$this->input->post('user_mobile'),
			'trainer'=>$this->input->post('trainer'),
			'batch_start_date'=>date("Y-m-d", strtotime($this->input->post('date'))),
		);
		$email_check=json_decode($this->crud->commonCheck('id','user',array('email'=>$user['email'])));
		$this->load->view('profile',$this->data);
	}
	function update_profile() {
		($this->user_id=='')?redirect(base_url()):'';
		$name = $this->input->post('name');
		$email = $this->input->post('email');
		$mobile = $this->input->post('mobile');
		$branch = $this->input->post('branch');
		$batch = $this->input->post('batch');
		$error='';
		if($name=="")$error=' Please enter your name!';
		if($email=="")$error=' Please enter your email!';
		if($mobile=="")$error=' Please enter your mobile!';
		if($branch=="")$error=' Please enter your branch!';
		if($batch=="")$error=' Please enter your batch!';
		if($error!=''){
			$response[CODE] = FAIL_CODE;
			$response[MESSAGE] = 'fail';
			$response[DESCRIPTION] =$error;
		}else{
				$data=array(
							'name'=>$name,
							'email'=>$email,
							'mobile'=>$mobile,
							'branch'=>$branch,
							'batch'=>$batch,
							
						);
				$where=array('id'=>$this->user_id);
				$res=json_decode($this->crud->commonUpdate('user',$data,$where,''));
				$response[CODE] = SUCCESS_CODE;
				$response[MESSAGE] = 'SUCCESS';
				$response[DESCRIPTION] ='Your profile has been updated successfully';
		}
		echo json_encode($response);
	}
	public function check_old_password(){
		$old_password = md5($this->input->post('old_password'));
		$params = array('id'=>$this->user_id,'password'=>$old_password);
		if($this->crud->commonCheck('id', 'user', $params)==1){
			$response[CODE] = SUCCESS_CODE;
			$response[MESSAGE] = 'SUCCESS';
			$response[DESCRIPTION] ='Old Password Match';
		}else{
			$response[CODE] = FAIL_CODE;
			$response[MESSAGE] = 'fail';
			$response[DESCRIPTION] ='Old Password Do Not Match';
		}
		echo json_encode($response);
	}
	public function change_password(){
		$response = array();
		$old_password=md5($this->input->post('old_password'));
		$new_password=md5($this->input->post('new_password'));
		$confirm_password=md5($this->input->post('confirm_password'));
		$error='';
		if($old_password=="")$error='Enter current password!';
		if($new_password=="")$error.=' Enter new password!';
		if($confirm_password=="")$error.='Enter same password!';
		if($confirm_password!=$new_password)$error.='New password and confirm password is not matching';
		if($confirm_password==$old_password)$error.='Current password and new password should not be same!';
		if($error!="")
		{
			$response=array('code'=>FAIL_CODE,'description'=>$error);
		}else{
			$confirm_password_exists=$this->crud->commonCheck('password', 'user', array('password'=>$old_password));
			if($confirm_password_exists!=1){
				$response[CODE]=EXISTS_CODE;
				$response[DESCRIPTION]='Your current password is not matching';
			}else{
					$data=array(
					'password'=>$confirm_password,
					);
					$where=array('id'=>$this->user_id);
					$res=json_decode($this->crud->commonUpdate('user',$data,$where,'success'));
					$response[CODE] = SUCCESS_CODE;
					$response[MESSAGE] = 'SUCCESS';
					$response[DESCRIPTION] ='Your Password has been updated successfully.Please Login again.';
					// $this->load->view('templates/email_verfication',array('data' => $email_data));
			}
		}
		echo json_encode($response);
	}
	public function user_logout(){
	  $this->session->sess_destroy();
	  // $this->load->view('register');
	  redirect(base_url());
	}
	//profile password update code
    public function forgotPassword()
	{
        $response=array();
        $error_message='';
        $req_input=file_get_contents('php://input');
        if(isJson($req_input) || SITE_MODE==0)
        {
            $req_response=json_decode($req_input);
            $email=(isset($req_response->email))?input_data($req_response->email):'';
			// $email='rkshinde1996@gmail.com';
            $error=0;
            /*validation code Start*/
            if (!email_check($email)) {
                $error_message.='* invalid email ,';
                $error = 1;
            }
			/*validation code End*/
            if($error==0)
            {
                $params['table']='user';
                $params['where']=array('email'=>$email);
				$userexist=json_decode($this->crud->commonget($params));
				if ($userexist->code==SUCCESS_CODE){
                    /*>>sending email code starts*/
					$userexist=$userexist->result[0];
					$id=$userexist->id;
					$email=$userexist->email;
					$name=$userexist->name;
					$mobile=$userexist->mobile;
					$vlink=md5($id).time();
					// $link=base64_encode(time().$id);
					$email_vlink=base_url().'reset-password/';
					$returndata=array(
						'id'=>$id,
						'name'=>$name,
						'email'=>$email,
						'link'=>$email_vlink.$vlink,
					);
					// print_r($res);exit;
					$email_data= array(
						'name'=>$name,
						'vlink'=>$email_vlink.base64_encode($id).'/'.$vlink,
						'message'=>' To reset your password click the link below. If your are not requested just ignore this email and your password will stay as it is. ');
					$email_array = array(
						'to' =>array($email),
						'cc' => array($email),
						'subject' => SITE_TITLE.' - Reset Password',
						'data' => array('data' => $email_data),
						'template' =>'templates/reset_password',
					);
					// print_r($email_array);exit;
					// $this->load->view('templates/reset_password',$email_array['data']);
					$result_mail=1;
					$result=(SEND_MAIL==1)?$this->sendmail->sendEmail($email_array):'';
					$result_mail=(SEND_MAIL==1)?$result['code']:1;
					// print_r($result);exit;
					if($result_mail==1){
						$data=array(
							'v_code'=>$vlink
						);
						$where=array('id'=>$id);
						$res=json_decode($this->crud->commonUpdate('user',$data,$where,'success'));
						$response[CODE] = SUCCESS_CODE;
						$response[MESSAGE] = 'SUCCESS';
						$response[DESCRIPTION] ='Please check your mail box. Password Reset link has been sent on your email address.';
						// $this->load->view('templates/email_verfication',array('data' => $email_data));
					}else{
						$response[CODE] = FAIL_CODE;
						$response[MESSAGE] = 'fail';
						$response[DESCRIPTION] ='Error while sending the mail';
					}
					//  $this->registerEmail($data); // Sending the email
					/* Sending the OTP COde */
					// print_r($g);exit;
                } else {
                    $error_message = 'email is not registered';
                    $response[CODE] = EXISTS_CODE;
                    $response[MESSAGE] = 'Account not exists';
                    $response[DESCRIPTION] = "Oops! $email is not registered. Please enter correct email.";
                }
            }else{
                $response[CODE]=VALIDATION_CODE;
                $response[MESSAGE]='Validation';
                $response[DESCRIPTION]=$error_message;
            }
        }else{
            $error_message='Input data should be in JSON format only';
            $response[CODE]=VALIDATION_CODE;
            $response[MESSAGE]='Validation';
            $response[DESCRIPTION]=$error_message;
        }
        echo json_encode($response);
    }
    public function verifycode(){
		$user_id=base64_decode($this->uri->segment(2));
		$vlink=$this->uri->segment(3);
		$this->data['URL_TITLE']=SITE_TITLE.' | Reset Password';
		$this->data['PAGE_TITLE'] = 'Reset Password';
		$breadcrumb_array = array
		(
			array('title' => 'Reset Password', 'link' =>'javascript:void(0)', 'class' => 'active'),
		);
		$this->data['breadcrumb'] = json_encode($breadcrumb_array);
		$params['table']='user';
		$params['where']=array('v_code'=>$vlink,'id'=>$user_id);
		// print_r($params);exit;
		$this->data['vcode']=json_decode($this->crud->commonget($params));
		// print_R($this->data['vcode']);exit;
		$this->data['URL_TITLE'] = 'Reset Password';
		$this->data['fp_code'] = $vlink;
		$this->data['user_id'] = $user_id;
		$this->load->view('reset_password',$this->data);
	}
	//profile password update code
    public function resetpassword()
    {
        $response=array();
        $error_message='';
        $req_input=file_get_contents('php://input');
        if(isJson($req_input))
        {
			$req_response=json_decode($req_input);
            $fp_code=(isset($req_response->fp_code))?input_data($req_response->fp_code):'';
            $user_id=(isset($req_response->user_id))?input_data($req_response->user_id):'';
            $confpassword=(isset($req_response->confpassword))?input_data($req_response->confpassword):'';
            $newpassword=(isset($req_response->newpassword))?$req_response->newpassword:'';
            $error=0;
            /*validation code Start*/
            // if(strlen($newpassword) < 6){$error_message='* new password length should be minimum 6 required.';$error=1;}
            if($newpassword!=$confpassword){$error_message='Entered password not matched';$error=1;}
            /*validation code End*/
            if($error==0)
            {
				$params['table']='user';
                $params['where']=array('v_code'=>$fp_code,'id'=>$user_id);
				$userexist=json_decode($this->crud->commonget($params));
				// print_r($userexist);exit;
				if ($userexist->code==SUCCESS_CODE){
                    /*>>sending email code starts*/
					$userexist=$userexist->row;
					$id=$userexist->id;
					$email=$userexist->email;
					$name=$userexist->name;
					$oldpwd=$userexist->password;
					$pwd=md5($newpassword);
					if($oldpwd==$pwd){
						$response[CODE]=EXISTS_CODE;
						$response[MESSAGE]='exists';
						$response[DESCRIPTION]='Dear '.ucwords($name).', <br/>you entered your old password. If you remembered it <a class="btn btn-primary" href="'.base_url().'">Login Here</a>';
					}else{
						$update_array=array(
							'password'=>$pwd,
							'v_code'=>'',
						);
						$update_where=array('id'=>$id);
						$response=json_decode($this->crud->commonUpdate($params['table'],$update_array,$update_where,'Your password is now reset!'));
					}
				} else {
                    $response[CODE] = EXISTS_CODE;
                    $response[MESSAGE] = 'error';
                    $response[DESCRIPTION] = "Invalid request.";
                }
			}else{
                $response[CODE]=VALIDATION_CODE;
                $response[MESSAGE]='Validation';
                $response[DESCRIPTION]=$error_message;
            }
        }else{
            $error_message='Input data should be in JSON format only';
            $response[CODE]=VALIDATION_CODE;
            $response[MESSAGE]='Validation';
            $response[DESCRIPTION]=$error_message;
        }
        echo json_encode($response);
    }
	public function do_upload(){
		$this->load->library('upload');
		$dataInfo = array();
		$insertArr = array();
		$this->data['imageError']=array();
		$files = $_FILES;
		$name=$this->input->post('nameImg');
		$assignmentModule=$this->input->post('assignmentModule');
		$cpt = count($_FILES[$name]['name']);
		// print_r($_FILES[$name]['name']);exit;
		if($cpt>0){
			for($i=0; $i<$cpt; $i++)
			{
				$_FILES[$name]['name']= $files[$name]['name'][$i];
				$_FILES[$name]['type']= $files[$name]['type'][$i];
				$_FILES[$name]['tmp_name']= $files[$name]['tmp_name'][$i];
				$_FILES[$name]['error']= $files[$name]['error'][$i];
				$_FILES[$name]['size']= $files[$name]['size'][$i];
				$this->upload->initialize($this->set_upload_options());
				if(!$this->upload->do_upload($name)){
					$this->data['imageError'][] =  $this->upload->display_errors();
				}else{
					$dataInfo= $this->upload->data();
					$insertArr[]=array('user_id'=>$this->user_id,'image'=>$dataInfo['file_name'],'type'=>$name,'assignment_module'=>$assignmentModule,'added_on'=>DATE,'status'=>1);
				}
			}
			if(count($insertArr)>0){
				$response = json_decode($this->crud->batchInsert('dt_assignments_completed_tbl',$insertArr,' Assignments submitted successfully!'));
			}else{
				$response[CODE]=FAIL_CODE;
				$response[MESSAGE]='fail';
				$response[DESCRIPTION]=' You are not selected any images!';	
			}
			if(count($this->data['imageError'])>0){
				$response[CODE]=VALIDATION_CODE;
				$response[DESCRIPTION]=implode(',',$this->data['imageError']);
			}
		}else{
			$response[CODE]=FAIL_CODE;
			$response[MESSAGE]='fail';
			$response[DESCRIPTION]=' You are not selected any images!';
		}
		echo json_encode($response);
	}
	private function set_upload_options()
	{   
		//upload an image options
		$config = array();
		$config['upload_path'] = './uploads/assignments/';
		$config['allowed_types'] = 'gif|jpg|png';
		$config['max_size']      = '0';
		$config['overwrite']     = FALSE;
		return $config;
	}
}