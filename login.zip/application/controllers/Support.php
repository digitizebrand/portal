<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Support extends CI_Controller {
	public $data = '';
	public function __construct(){
        parent::__construct();
  	 	$this->load->model('user_model');
		$this->user_id=$this->session->userdata('user_id');
		$this->data['user_id']=$this->user_id;
		$this->controller_path=base_url().'support';
		$this->payment_status=$this->crud->commonCheck('id', 'user', array('payment'=>1,'id'=>$this->user_id));
		$params = array('table'=>'dt_branches_tbl','where'=>array('status'=>1));	
		$this->data['branches']=json_decode($this->crud->commonget($params));
		$params = array('table'=>'bd_tbl','where'=>array('status'=>1));
		$this->data['bds']=json_decode($this->crud->commonget($params));
		$params = array('table'=>'batches_tbl','where'=>array('status'=>1));
		$this->data['batches']=json_decode($this->crud->commonget($params));
		$params = array('table'=>'dt_trainer_tbl','where'=>array('status'=>1));
		$this->data['trainer']=json_decode($this->crud->commonget($params));
	}
	public function index()
	{
		($this->user_id!='')?'':redirect(base_url());	
		$this->load->view("support",$this->data);
	}
	public function ss(){
		$this->form_validation->set_rules('name','name','required',array('required'=>'Enter the name of company'));
		$this->form_validation->set_error_delimiters('<span class="error"> ','</span>');
		if($this->form_validation->run()==false)
		{
			$this->load->view('dt_placements',$this->data);
		}else{
			
		}
	}
	public function register_user(){
		$password=$this->input->post('user_password1');
		$name=ucwords($this->input->post('user_name'));
		$email=$this->input->post('user_email');
		$user=array(
			'name'=>$name,
			'email'=>$email,
			'branch'=>$this->input->post('branch'),
			'batch'=>$this->input->post('batch'),
			'bd'=>$this->input->post('bd'),
			'password'=>md5($password),
			'mobile'=>$this->input->post('user_mobile'),
			'trainer'=>$this->input->post('trainer'),
			'purpose'=>$this->input->post('purpose'),
			'batch_start_date'=>date("Y-m-d", strtotime($this->input->post('date'))),
			'status'=>0,
			'added_on'=>DATE,
			'payment'=>0	  
		);
		$email_check=json_decode($this->crud->commonCheck('id','user',array('email'=>$user['email'])));
		if($email_check==0){
			$res=json_decode($this->crud->commonInsert('user',$user,'success'));
			if($res->code==SUCCESS_CODE){
				$email_data= array(
					'name'=>$name,
					'title'=>SITE_TITLE.' Credentials',
					'link_title'=>' Login Here',
					'vlink'=>base_url(),
					'message'=>" Thank you for signing up with us. Below are the credentials of your ".SITE_TITLE." account. Save this for future references.<br/> <br/>
						Username: $email,<br/>
						Password: $password<br/>
						<br/><br/>
					<p style='color:red' align='justify'><sup>*</sup> You will receive an email once your account get activated. It will take 24 to 48 hours for activation. If you do not receive an email within 24 to 48 hours contact your Trainer.</p>"
				);
				$email_array = array(
					'to' =>array($email),
					'cc' => array($email),
					'subject' => "$name, your ".SITE_TITLE." registration process has been completed",
					'data' => array('data' => $email_data),
					'template' =>'templates/credentials',
				);
				$result=(SEND_MAIL==1)?$this->sendmail->sendEmail($email_array):'';
				$result_mail=(SEND_MAIL==1)?$result['code']:1;
			}
			// $this->user_model->register_user($user);
			$this->session->set_flashdata('success_msg1', 'Registered successfully.');
			redirect(base_url());
		}else{
			// echo 'fail';
			$this->session->set_flashdata('error_msg1', $user['email'].' is already exists.');
			$this->load->view("register",$this->data);
		}
	}
	public function login_view(){
		($this->user_id=='')?'':redirect(base_url().'user/dashboard/');
		$this->load->view("login");
	}

	//profile password update code
    public function resetpassword()
    {
        $response=array();
        $error_message='';
        $req_input=file_get_contents('php://input');
        if(isJson($req_input))
        {
			$req_response=json_decode($req_input);
            $fp_code=(isset($req_response->fp_code))?input_data($req_response->fp_code):'';
            $user_id=(isset($req_response->user_id))?input_data($req_response->user_id):'';
            $confpassword=(isset($req_response->confpassword))?input_data($req_response->confpassword):'';
            $newpassword=(isset($req_response->newpassword))?$req_response->newpassword:'';
            $error=0;
            /*validation code Start*/
            // if(strlen($newpassword) < 6){$error_message='* new password length should be minimum 6 required.';$error=1;}
            if($newpassword!=$confpassword){$error_message='Entered password not matched';$error=1;}
            /*validation code End*/
            if($error==0)
            {
				$params['table']='user';
                $params['where']=array('v_code'=>$fp_code,'id'=>$user_id);
				$userexist=json_decode($this->crud->commonget($params));
				// print_r($userexist);exit;
				if ($userexist->code==SUCCESS_CODE){
                    /*>>sending email code starts*/
					$userexist=$userexist->row;
					$id=$userexist->id;
					$email=$userexist->email;
					$name=$userexist->name;
					$oldpwd=$userexist->password;
					$pwd=md5($newpassword);
					if($oldpwd==$pwd){
						$response[CODE]=EXISTS_CODE;
						$response[MESSAGE]='exists';
						$response[DESCRIPTION]='Dear '.ucwords($name).', <br/>you entered your old password. If you remembered it <a class="btn btn-primary" href="'.base_url().'">Login Here</a>';
					}else{
						$update_array=array(
							'password'=>$pwd,
							'v_code'=>'',
						);
						$update_where=array('id'=>$id);
						$response=json_decode($this->crud->commonUpdate($params['table'],$update_array,$update_where,'Your password is now reset!'));
					}
				} else {
                    $response[CODE] = EXISTS_CODE;
                    $response[MESSAGE] = 'error';
                    $response[DESCRIPTION] = "Invalid request.";
                }
			}else{
                $response[CODE]=VALIDATION_CODE;
                $response[MESSAGE]='Validation';
                $response[DESCRIPTION]=$error_message;
            }
        }else{
            $error_message='Input data should be in JSON format only';
            $response[CODE]=VALIDATION_CODE;
            $response[MESSAGE]='Validation';
            $response[DESCRIPTION]=$error_message;
        }
        echo json_encode($response);
    }
	public function do_upload(){
		$this->load->library('upload');
		$dataInfo = array();
		$insertArr = array();
		$this->data['imageError']=array();
		$files = $_FILES;
		$name=$this->input->post('nameImg');
		$assignmentModule=$this->input->post('assignmentModule');
		$cpt = count($_FILES[$name]['name']);
		// print_r($_FILES[$name]['name']);exit;
		if($cpt>0){
			for($i=0; $i<$cpt; $i++)
			{
				$_FILES[$name]['name']= $files[$name]['name'][$i];
				$_FILES[$name]['type']= $files[$name]['type'][$i];
				$_FILES[$name]['tmp_name']= $files[$name]['tmp_name'][$i];
				$_FILES[$name]['error']= $files[$name]['error'][$i];
				$_FILES[$name]['size']= $files[$name]['size'][$i];
				$this->upload->initialize($this->set_upload_options());
				if(!$this->upload->do_upload($name)){
					$this->data['imageError'][] =  $this->upload->display_errors();
				}else{
					$dataInfo= $this->upload->data();
					$insertArr[]=array('user_id'=>$this->user_id,'image'=>$dataInfo['file_name'],'type'=>$name,'assignment_module'=>$assignmentModule,'added_on'=>DATE,'status'=>1);
				}
			}
			if(count($insertArr)>0){
				$response = json_decode($this->crud->batchInsert('dt_assignments_completed_tbl',$insertArr,' Assignments submitted successfully!'));
			}else{
				$response[CODE]=FAIL_CODE;
				$response[MESSAGE]='fail';
				$response[DESCRIPTION]=' You are not selected any images!';	
			}
			if(count($this->data['imageError'])>0){
				$response[CODE]=VALIDATION_CODE;
				$response[DESCRIPTION]=implode(',',$this->data['imageError']);
			}
		}else{
			$response[CODE]=FAIL_CODE;
			$response[MESSAGE]='fail';
			$response[DESCRIPTION]=' You are not selected any images!';
		}
		echo json_encode($response);
	}
	private function set_upload_options()
	{   
		//upload an image options
		$config = array();
		$config['upload_path'] = './uploads/assignments/';
		$config['allowed_types'] = 'gif|jpg|png';
		$config['max_size']      = '0';
		$config['overwrite']     = FALSE;
		return $config;
	}
}